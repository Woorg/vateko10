# WordPress MySQL database migration
#
# Generated: Thursday 4. August 2022 06:12 UTC
# Hostname: mysql
# Database: `vateko`
# URL: //vateko.loc
# Path: /var/www/vateko
# Tables: wp_commentmeta, wp_comments, wp_ewwwio_images, wp_ewwwio_queue, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, page, post, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2022-08-02 10:37:17', '2022-08-02 07:37:17', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_images`
#

DROP TABLE IF EXISTS `wp_ewwwio_images`;


#
# Table structure of table `wp_ewwwio_images`
#

CREATE TABLE `wp_ewwwio_images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint unsigned DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `results` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image_size` int unsigned DEFAULT NULL,
  `orig_size` int unsigned DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `level` int unsigned DEFAULT NULL,
  `pending` tinyint NOT NULL DEFAULT '0',
  `updates` int unsigned DEFAULT NULL,
  `updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob,
  PRIMARY KEY (`id`),
  KEY `path` (`path`(191)),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_ewwwio_images`
#
INSERT INTO `wp_ewwwio_images` ( `id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 19, 'media', 'full', 'ABSPATHwp-content/uploads/2022/08/hero-img.png', '', 'Уменьшено на 8,2% (87,6 КБ)', 1003797, 1093480, '', 10, 0, 1, '2022-08-03 14:04:40', NULL),
(2, 19, 'media', 'medium', 'ABSPATHwp-content/uploads/2022/08/hero-img-300x146.png', '', 'Уменьшено на 4,7% (2,2 КБ)', 45951, 48193, '', 10, 0, 1, '2022-08-03 14:04:44', NULL),
(3, 19, 'media', 'large', 'ABSPATHwp-content/uploads/2022/08/hero-img-1024x497.png', '', 'Уменьшено на 7,9% (29,0 КБ)', 346771, 376471, '', 10, 0, 1, '2022-08-03 14:05:02', NULL),
(4, 19, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2022/08/hero-img-150x150.png', '', 'Уменьшено на 14,9% (3,8 КБ)', 22264, 26170, '', 10, 0, 1, '2022-08-03 14:05:03', NULL),
(5, 19, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2022/08/hero-img-768x373.png', '', 'Уменьшено на 7,0% (15,2 КБ)', 206212, 221811, '', 10, 0, 1, '2022-08-03 14:05:13', NULL),
(6, 19, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2022/08/hero-img-1536x746.png', '', 'Уменьшено на 8,5% (68,3 КБ)', 752822, 822741, '', 10, 0, 1, '2022-08-03 14:06:05', NULL) ;

#
# End of data contents of table `wp_ewwwio_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_queue`
#

DROP TABLE IF EXISTS `wp_ewwwio_queue`;


#
# Table structure of table `wp_ewwwio_queue`
#

CREATE TABLE `wp_ewwwio_queue` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint unsigned DEFAULT NULL,
  `gallery` varchar(20) DEFAULT NULL,
  `scanned` tinyint NOT NULL DEFAULT '0',
  `new` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ewwwio_queue`
#

#
# End of data contents of table `wp_ewwwio_queue`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://vateko.loc', 'yes'),
(2, 'home', 'http://vateko.loc', 'yes'),
(3, 'blogname', 'Эковата «ВАТЭКО» — безопасный утеплитель', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'gorlov35@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:94:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:22:"cyr2lat/cyr-to-lat.php";i:3;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:4;s:27:"redis-cache/redis-cache.php";i:5;s:21:"safe-svg/safe-svg.php";i:6;s:13:"soil/soil.php";i:7;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'vateko10', 'yes'),
(41, 'stylesheet', 'vateko10', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1674977836', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:14:"sidebar-footer";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:9:{i:1659425838;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1659425839;a:5:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1659425955;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1659425959;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1659426015;a:1:{s:28:"wp_update_comment_type_batch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1659426779;a:1:{s:26:"rediscache_discard_metrics";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1659442706;a:1:{s:39:"ewww_image_optimizer_relative_migration";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:34:"ewwwio_relative_migration_interval";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1659512239;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1659427662;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(134, 'can_compress_scripts', '1', 'no'),
(152, 'recently_activated', 'a:0:{}', 'yes'),
(158, 'new_admin_email', 'gorlov35@gmail.com', 'yes'),
(159, 'current_theme', 'Sage Starter Theme', 'yes'),
(160, 'theme_mods_vateko', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1659440988;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:14:"sidebar-footer";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(161, 'theme_switched', '', 'yes'),
(162, 'acf_version', '5.12.2', 'yes'),
(164, 'theme_mods_vateko10', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:3;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(166, 'ewww_image_optimizer_relative_migration_status', 'done', 'yes'),
(167, 'ewww_image_optimizer_noauto', '', 'yes'),
(168, 'ewww_image_optimizer_disable_editor', '', 'yes'),
(169, 'ewww_image_optimizer_debug', '', 'yes'),
(170, 'ewww_image_optimizer_metadata_remove', '1', 'yes'),
(171, 'ewww_image_optimizer_jpg_level', '0', 'yes'),
(172, 'ewww_image_optimizer_png_level', '0', 'yes'),
(173, 'ewww_image_optimizer_gif_level', '0', 'yes'),
(174, 'ewww_image_optimizer_pdf_level', '0', 'yes'),
(175, 'ewww_image_optimizer_svg_level', '0', 'yes'),
(176, 'ewww_image_optimizer_jpg_quality', '100', 'yes'),
(177, 'ewww_image_optimizer_webp_quality', '100', 'yes'),
(178, 'ewww_image_optimizer_resize_existing', '1', 'yes'),
(179, 'ewww_image_optimizer_exactdn', '', 'yes'),
(181, 'exactdn_all_the_things', '1', 'yes'),
(182, 'exactdn_lossy', '1', 'yes'),
(183, 'exactdn_exclude', '', 'yes'),
(184, 'exactdn_sub_folder', '', 'no'),
(185, 'exactdn_prevent_db_queries', '', 'yes'),
(186, 'ewww_image_optimizer_lazy_load', '1', 'yes'),
(187, 'ewww_image_optimizer_use_siip', '', 'yes'),
(188, 'ewww_image_optimizer_use_lqip', '', 'yes'),
(189, 'ewww_image_optimizer_ll_exclude', '', 'yes'),
(190, 'ewww_image_optimizer_ll_all_things', '', 'yes'),
(191, 'ewww_image_optimizer_disable_pngout', '1', 'yes'),
(192, 'ewww_image_optimizer_disable_svgcleaner', '1', 'yes'),
(193, 'ewww_image_optimizer_optipng_level', '2', 'yes'),
(194, 'ewww_image_optimizer_pngout_level', '2', 'yes'),
(195, 'ewww_image_optimizer_webp_for_cdn', '1', 'yes'),
(196, 'ewww_image_optimizer_force_gif2webp', '', 'yes'),
(197, 'ewww_image_optimizer_picture_webp', '1', 'yes'),
(198, 'ewww_image_optimizer_webp_rewrite_exclude', '', 'yes'),
(200, 'ewww_image_optimizer_ll_autoscale', '1', 'no'),
(201, 'exactdn_never_been_active', '1', 'no'),
(202, 'ewww_image_optimizer_bulk_resume', '', 'yes'),
(203, 'ewww_image_optimizer_aux_resume', '', 'yes'),
(204, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(205, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(207, 'ewww_image_optimizer_review_time', '1660047512', 'no'),
(208, 'ewww_image_optimizer_version', '670', 'yes'),
(209, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(210, 'options_logo_image', '14', 'yes'),
(211, '_options_logo_image', 'field_Настройки_темы_logo_image', 'yes'),
(212, 'options_address', '', 'yes'),
(213, '_options_address', 'field_Настройки_темы_address', 'yes'),
(214, 'options_phone', '+ 7 (999) 888-77-66', 'yes'),
(215, '_options_phone', 'field_Настройки_темы_phone', 'yes'),
(216, 'options_lat', '', 'yes'),
(217, '_options_lat', 'field_Настройки_темы_lat', 'yes'),
(218, 'options_long', '', 'yes'),
(219, '_options_long', 'field_Настройки_темы_long', 'yes'),
(220, 'options_copyright', '2020-2021 г. © <span>Все права защищены</span><small>Копирование сайта и материалов запрещено.</small>', 'yes'),
(221, '_options_copyright', 'field_Настройки_темы_copyright', 'yes'),
(222, 'options_text', '', 'yes'),
(223, '_options_text', 'field_Настройки_темы_text', 'yes'),
(224, 'options_text_2', '', 'yes'),
(225, '_options_text_2', 'field_Настройки_темы_text_2', 'yes'),
(226, 'options_vk_url', '', 'yes'),
(227, '_options_vk_url', 'field_Настройки_темы_vk_url', 'yes'),
(228, 'options_telegram_url', '', 'yes'),
(229, '_options_telegram_url', 'field_Настройки_темы_telegram_url', 'yes'),
(230, 'options_whatsup_url', '', 'yes'),
(231, '_options_whatsup_url', 'field_Настройки_темы_whatsup_url', 'yes'),
(232, 'options_email', 'ecovata@gmail.com', 'yes'),
(233, '_options_email', 'field_Настройки_темы_email', 'yes'),
(234, 'ewww_image_optimizer_backup_files', '', 'no'),
(235, 'ewww_image_optimizer_wizard_complete', '1', 'no'),
(236, 'ewww_image_optimizer_local_mode', '1', 'yes'),
(237, 'ewww_image_optimizer_avif_quality', '', 'yes'),
(238, 'ewww_image_optimizer_aux_paths', '', 'yes'),
(239, 'ewww_image_optimizer_exclude_paths', '', 'yes'),
(241, 'ewww_image_optimizer_maxmediawidth', '0', 'yes'),
(242, 'ewww_image_optimizer_maxmediaheight', '0', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(243, 'ewww_image_optimizer_disable_resizes', '', 'yes'),
(244, 'ewww_image_optimizer_disable_resizes_opt', '', 'yes'),
(245, 'ewww_image_optimizer_jpg_background', '', 'yes'),
(246, 'ewww_image_optimizer_webp', '1', 'yes'),
(247, 'ewww_image_optimizer_webp_force', '1', 'yes'),
(248, 'ewww_image_optimizer_webp_paths', '', 'yes'),
(251, 'ewww_image_optimizer_hide_newsletter_signup', '1', 'no'),
(252, 'ewww_image_optimizer_sharpen', '1', 'yes'),
(253, 'ewww_image_optimizer_include_media_paths', '1', 'yes'),
(255, 'ewww_image_optimizer_aux_folders_completed', 'a:0:{}', 'no'),
(256, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:36:"HTTPS запрос неудачен.";}}', 'yes'),
(268, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1659593579;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 2, '_edit_lock', '1659593546:1'),
(4, 9, '_menu_item_type', 'custom'),
(5, 9, '_menu_item_menu_item_parent', '0'),
(6, 9, '_menu_item_object_id', '9'),
(7, 9, '_menu_item_object', 'custom'),
(8, 9, '_menu_item_target', ''),
(9, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(10, 9, '_menu_item_xfn', ''),
(11, 9, '_menu_item_url', '#'),
(13, 10, '_menu_item_type', 'custom'),
(14, 10, '_menu_item_menu_item_parent', '0'),
(15, 10, '_menu_item_object_id', '10'),
(16, 10, '_menu_item_object', 'custom'),
(17, 10, '_menu_item_target', ''),
(18, 10, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(19, 10, '_menu_item_xfn', ''),
(20, 10, '_menu_item_url', '#'),
(22, 11, '_menu_item_type', 'custom'),
(23, 11, '_menu_item_menu_item_parent', '0'),
(24, 11, '_menu_item_object_id', '11'),
(25, 11, '_menu_item_object', 'custom'),
(26, 11, '_menu_item_target', ''),
(27, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(28, 11, '_menu_item_xfn', ''),
(29, 11, '_menu_item_url', '#'),
(31, 12, '_menu_item_type', 'custom'),
(32, 12, '_menu_item_menu_item_parent', '0'),
(33, 12, '_menu_item_object_id', '12'),
(34, 12, '_menu_item_object', 'custom'),
(35, 12, '_menu_item_target', ''),
(36, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(37, 12, '_menu_item_xfn', ''),
(38, 12, '_menu_item_url', '#'),
(40, 13, '_menu_item_type', 'custom'),
(41, 13, '_menu_item_menu_item_parent', '0'),
(42, 13, '_menu_item_object_id', '13'),
(43, 13, '_menu_item_object', 'custom'),
(44, 13, '_menu_item_target', ''),
(45, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(46, 13, '_menu_item_xfn', ''),
(47, 13, '_menu_item_url', '#'),
(49, 14, '_wp_attached_file', '2022/08/logo.svg'),
(50, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:118;s:6:"height";i:39;s:4:"file";s:16:"2022/08/logo.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:8:"logo.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}}s:8:"filesize";i:13544;}'),
(51, 14, '_wp_attachment_image_alt', 'логотип'),
(52, 2, '_edit_last', '1'),
(53, 2, 'page_short_title', ''),
(54, 2, '_page_short_title', 'field_page_extra_page_short_title'),
(57, 16, 'page_short_title', ''),
(58, 16, '_page_short_title', 'field_page_extra_page_short_title'),
(59, 18, 'page_short_title', ''),
(60, 18, '_page_short_title', 'field_page_extra_page_short_title'),
(61, 19, '_wp_attached_file', '2022/08/hero-img.png'),
(62, 19, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1680;s:6:"height";i:816;s:4:"file";s:20:"2022/08/hero-img.png";s:8:"filesize";i:1003797;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:20:"hero-img-300x146.png";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45951;}s:5:"large";a:5:{s:4:"file";s:21:"hero-img-1024x497.png";s:5:"width";i:1024;s:6:"height";i:497;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:346771;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"hero-img-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:22264;}s:12:"medium_large";a:5:{s:4:"file";s:20:"hero-img-768x373.png";s:5:"width";i:768;s:6:"height";i:373;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:206212;}s:9:"1536x1536";a:5:{s:4:"file";s:21:"hero-img-1536x746.png";s:5:"width";i:1536;s:6:"height";i:746;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:752822;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(63, 22, 'page_short_title', ''),
(64, 22, '_page_short_title', 'field_page_extra_page_short_title'),
(65, 23, 'page_short_title', ''),
(66, 23, '_page_short_title', 'field_page_extra_page_short_title'),
(67, 26, 'page_short_title', ''),
(68, 26, '_page_short_title', 'field_page_extra_page_short_title'),
(69, 27, 'page_short_title', ''),
(70, 27, '_page_short_title', 'field_page_extra_page_short_title'),
(71, 29, '_wp_attached_file', '2022/08/bigbuckbunny.mp4'),
(72, 29, '_wp_attachment_metadata', 'a:10:{s:8:"filesize";i:59228650;s:9:"mime_type";s:9:"video/mp4";s:6:"length";i:596;s:16:"length_formatted";s:4:"9:56";s:5:"width";i:1280;s:6:"height";i:720;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}s:17:"created_timestamp";i:-2082844800;}'),
(73, 31, 'page_short_title', ''),
(74, 31, '_page_short_title', 'field_page_extra_page_short_title'),
(75, 32, 'page_short_title', ''),
(76, 32, '_page_short_title', 'field_page_extra_page_short_title'),
(77, 34, '_wp_attached_file', '2022/08/about-img.png'),
(78, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:798;s:6:"height";i:582;s:4:"file";s:21:"2022/08/about-img.png";s:8:"filesize";i:782095;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"about-img-300x219.png";s:5:"width";i:300;s:6:"height";i:219;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:123929;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"about-img-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44928;}s:12:"medium_large";a:5:{s:4:"file";s:21:"about-img-768x560.png";s:5:"width";i:768;s:6:"height";i:560;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:662875;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(79, 36, 'page_short_title', ''),
(80, 36, '_page_short_title', 'field_page_extra_page_short_title'),
(81, 39, 'page_short_title', ''),
(82, 39, '_page_short_title', 'field_page_extra_page_short_title') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-08-02 10:37:17', '2022-08-02 07:37:17', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2022-08-02 10:37:17', '2022-08-02 07:37:17', '', 0, 'http://vateko.loc/?p=1', 0, 'post', '', 1),
(2, 1, '2022-08-02 10:37:17', '2022-08-02 07:37:17', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62ead8a27381f","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного \\u003cstrong\\u003eутепления домов\\u003c/strong\\u003e,\\r\\n\\u003cstrong\\u003eмансард\\u003c/strong\\u003e, \\u003cstrong\\u003eангаров\\u003c/strong\\u003e и других сооружений.","_about_text":"field_about_about_text","about_image":34,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->', 'Главная', '', 'publish', 'closed', 'open', '', 'glavnaya', '', '', '2022-08-03 23:42:18', '2022-08-03 20:42:18', '', 0, 'http://vateko.loc/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-08-02 10:37:17', '2022-08-02 07:37:17', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://vateko.loc.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-08-02 10:37:17', '2022-08-02 07:37:17', '', 0, 'http://vateko.loc/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-08-02 10:39:19', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-02 10:39:19', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?p=4', 0, 'post', '', 0),
(5, 1, '2022-08-02 17:49:57', '2022-08-02 14:49:57', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-vateko10', '', '', '2022-08-02 17:49:57', '2022-08-02 14:49:57', '', 0, 'http://vateko.loc/wp-global-styles-vateko10/', 0, 'wp_global_styles', '', 0),
(6, 1, '2022-08-02 17:50:08', '2022-08-02 14:50:08', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице «Детали» владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Привет! Днём я курьер, а вечером — подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Компания «Штучки XYZ» была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href="http://vateko.loc/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-02 17:50:08', '2022-08-02 14:50:08', '', 2, 'http://vateko.loc/?p=6', 0, 'revision', '', 0),
(7, 1, '2022-08-02 17:50:40', '2022-08-02 14:50:40', '', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-02 17:50:40', '2022-08-02 14:50:40', '', 2, 'http://vateko.loc/?p=7', 0, 'revision', '', 0),
(9, 1, '2022-08-02 22:51:52', '2022-08-02 19:51:52', '', 'Что такое ВатЭКО?', '', 'publish', 'closed', 'closed', '', 'chto-takoe-vateko', '', '', '2022-08-02 22:51:52', '2022-08-02 19:51:52', '', 0, 'http://vateko.loc/?p=9', 1, 'nav_menu_item', '', 0),
(10, 1, '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 'Наша продукция', '', 'publish', 'closed', 'closed', '', 'nasha-produkcziya', '', '', '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 0, 'http://vateko.loc/?p=10', 2, 'nav_menu_item', '', 0),
(11, 1, '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 'Преимущества', '', 'publish', 'closed', 'closed', '', 'preimushhestva', '', '', '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 0, 'http://vateko.loc/?p=11', 3, 'nav_menu_item', '', 0),
(12, 1, '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 'Стать партнером', '', 'publish', 'closed', 'closed', '', 'stat-partnerom', '', '', '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 0, 'http://vateko.loc/?p=12', 4, 'nav_menu_item', '', 0),
(13, 1, '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 'Контакты', '', 'publish', 'closed', 'closed', '', 'kontakty', '', '', '2022-08-02 22:51:53', '2022-08-02 19:51:53', '', 0, 'http://vateko.loc/?p=13', 5, 'nav_menu_item', '', 0),
(14, 1, '2022-08-02 23:07:10', '2022-08-02 20:07:10', '', 'Эковата «ВАТЭКО» — безопасный утеплитель', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2022-08-02 23:07:35', '2022-08-02 20:07:35', '', 0, 'http://vateko.loc/wp-content/uploads/2022/08/logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(16, 1, '2022-08-03 17:01:01', '2022-08-03 14:01:01', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"","_hero_title":"field_hero_hero_title","hero_image":"","_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:01:01', '2022-08-03 14:01:01', '', 2, 'http://vateko.loc/?p=16', 0, 'revision', '', 0),
(17, 1, '2022-08-03 17:02:22', '2022-08-03 14:02:22', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":"","_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:02:22', '2022-08-03 14:02:22', '', 2, 'http://vateko.loc/?p=17', 0, 'revision', '', 0),
(18, 1, '2022-08-03 17:02:28', '2022-08-03 14:02:28', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":"","_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:02:28', '2022-08-03 14:02:28', '', 2, 'http://vateko.loc/?p=18', 0, 'revision', '', 0),
(19, 1, '2022-08-03 17:03:24', '2022-08-03 14:03:24', '', 'hero-img', '', 'inherit', 'open', 'closed', '', 'hero-img', '', '', '2022-08-03 17:03:24', '2022-08-03 14:03:24', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/hero-img.png', 0, 'attachment', 'image/png', 0),
(21, 1, '2022-08-03 17:14:16', '2022-08-03 14:14:16', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:14:16', '2022-08-03 14:14:16', '', 2, 'http://vateko.loc/?p=21', 0, 'revision', '', 0),
(22, 1, '2022-08-03 17:14:20', '2022-08-03 14:14:20', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:14:20', '2022-08-03 14:14:20', '', 2, 'http://vateko.loc/?p=22', 0, 'revision', '', 0),
(23, 1, '2022-08-03 17:15:34', '2022-08-03 14:15:34', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:15:34', '2022-08-03 14:15:34', '', 2, 'http://vateko.loc/?p=23', 0, 'revision', '', 0),
(25, 1, '2022-08-03 17:28:22', '2022-08-03 14:28:22', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:28:22', '2022-08-03 14:28:22', '', 2, 'http://vateko.loc/?p=25', 0, 'revision', '', 0),
(26, 1, '2022-08-03 17:28:27', '2022-08-03 14:28:27', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 17:28:27', '2022-08-03 14:28:27', '', 2, 'http://vateko.loc/?p=26', 0, 'revision', '', 0),
(27, 1, '2022-08-03 18:46:29', '2022-08-03 15:46:29', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":"","_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 18:46:29', '2022-08-03 15:46:29', '', 2, 'http://vateko.loc/?p=27', 0, 'revision', '', 0),
(29, 1, '2022-08-03 22:40:57', '2022-08-03 19:40:57', '', 'BigBuckBunny', '', 'inherit', 'open', 'closed', '', 'bigbuckbunny', '', '', '2022-08-03 22:40:57', '2022-08-03 19:40:57', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/bigbuckbunny.mp4', 0, 'attachment', 'video/mp4', 0),
(30, 1, '2022-08-03 22:41:19', '2022-08-03 19:41:19', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 22:41:19', '2022-08-03 19:41:19', '', 2, 'http://vateko.loc/?p=30', 0, 'revision', '', 0),
(31, 1, '2022-08-03 22:41:24', '2022-08-03 19:41:24', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 22:41:24', '2022-08-03 19:41:24', '', 2, 'http://vateko.loc/?p=31', 0, 'revision', '', 0),
(32, 1, '2022-08-03 23:20:35', '2022-08-03 20:20:35', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 23:20:35', '2022-08-03 20:20:35', '', 2, 'http://vateko.loc/?p=32', 0, 'revision', '', 0),
(34, 1, '2022-08-03 23:21:55', '2022-08-03 20:21:55', '', 'about-img', '', 'inherit', 'open', 'closed', '', 'about-img', '', '', '2022-08-03 23:21:55', '2022-08-03 20:21:55', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/about-img.png', 0, 'attachment', 'image/png', 0),
(35, 1, '2022-08-03 23:23:33', '2022-08-03 20:23:33', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62ead8a27381f","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% — \\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":34,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 23:23:33', '2022-08-03 20:23:33', '', 2, 'http://vateko.loc/?p=35', 0, 'revision', '', 0),
(36, 1, '2022-08-03 23:23:37', '2022-08-03 20:23:37', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62ead8a27381f","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% — \\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":34,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 23:23:37', '2022-08-03 20:23:37', '', 2, 'http://vateko.loc/?p=36', 0, 'revision', '', 0),
(38, 1, '2022-08-03 23:42:13', '2022-08-03 20:42:13', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62ead8a27381f","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного \\u003cstrong\\u003eутепления домов\\u003c/strong\\u003e,\\r\\n\\u003cstrong\\u003eмансард\\u003c/strong\\u003e, \\u003cstrong\\u003eангаров\\u003c/strong\\u003e и других сооружений.","_about_text":"field_about_about_text","about_image":34,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 23:42:13', '2022-08-03 20:42:13', '', 2, 'http://vateko.loc/?p=38', 0, 'revision', '', 0),
(39, 1, '2022-08-03 23:42:18', '2022-08-03 20:42:18', '<!-- wp:acf/hero {"id":"block_62ea7e54e3e21","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":19,"_hero_image":"field_hero_hero_image","hero_file":29,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62ead8a27381f","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного \\u003cstrong\\u003eутепления домов\\u003c/strong\\u003e,\\r\\n\\u003cstrong\\u003eмансард\\u003c/strong\\u003e, \\u003cstrong\\u003eангаров\\u003c/strong\\u003e и других сооружений.","_about_text":"field_about_about_text","about_image":34,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-03 23:42:18', '2022-08-03 20:42:18', '', 2, 'http://vateko.loc/?p=39', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 2, 0),
(9, 3, 0),
(10, 3, 0),
(11, 3, 0),
(12, 3, 0),
(13, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 5) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'vateko10', 'vateko10', 0),
(3, 'Main nav', 'main-nav', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'vateko'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"2b05e0f5a8dcb3bf5d91726583efb131a50dd63de2861403620b48b8b0695f86";a:4:{s:10:"expiration";i:1659598755;s:2:"ip";s:10:"172.19.0.1";s:2:"ua";s:101:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36";s:5:"login";i:1659425955;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:13:"192.168.240.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(22, 1, 'wp_user-settings-time', '1659558217'),
(23, 1, 'closedpostboxes_page', 'a:1:{i:0;s:20:"acf-group_page_extra";}'),
(24, 1, 'metaboxhidden_page', 'a:0:{}'),
(25, 1, 'roc_dismissed_pro_release_notice', '1'),
(26, 1, 'closedpostboxes_dashboard', 'a:1:{i:0;s:21:"dashboard_site_health";}'),
(27, 1, 'metaboxhidden_dashboard', 'a:5:{i:0;s:19:"dashboard_right_now";i:1;s:18:"dashboard_activity";i:2;s:20:"dashboard_rediscache";i:3;s:21:"dashboard_quick_press";i:4;s:17:"dashboard_primary";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'vateko', '$P$BErrDfTRhA/M1sgcSgqEl5ut5jiops0', 'vateko', 'gorlov35@gmail.com', 'http://vateko.loc', '2022-08-02 07:37:17', '', 0, 'vateko') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

