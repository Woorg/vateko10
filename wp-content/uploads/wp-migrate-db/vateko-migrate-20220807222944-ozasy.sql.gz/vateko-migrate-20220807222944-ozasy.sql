# WordPress MySQL database migration
#
# Generated: Sunday 7. August 2022 22:29 UTC
# Hostname: mysql
# Database: `vateko`
# URL: //vateko.loc
# Path: /var/www/vateko
# Tables: wp_commentmeta, wp_comments, wp_ewwwio_images, wp_ewwwio_queue, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, page, post, product, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2022-08-06 22:12:38', '2022-08-06 19:12:38', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_images`
#

DROP TABLE IF EXISTS `wp_ewwwio_images`;


#
# Table structure of table `wp_ewwwio_images`
#

CREATE TABLE `wp_ewwwio_images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint unsigned DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `results` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image_size` int unsigned DEFAULT NULL,
  `orig_size` int unsigned DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `level` int unsigned DEFAULT NULL,
  `pending` tinyint NOT NULL DEFAULT '0',
  `updates` int unsigned DEFAULT NULL,
  `updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob,
  PRIMARY KEY (`id`),
  KEY `path` (`path`(191)),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_ewwwio_images`
#
INSERT INTO `wp_ewwwio_images` ( `id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 13, 'media', 'full', 'ABSPATHwp-content/uploads/2022/08/hero-img-1.png', '', 'Без экономии', 1003797, 1003797, '', 10, 0, 1, '2022-08-06 19:55:06', NULL),
(2, 13, 'media', 'medium', 'ABSPATHwp-content/uploads/2022/08/hero-img-1-300x146.png', '', 'Уменьшено на 0,0% (12,0 Б)', 44140, 44152, '', 10, 0, 1, '2022-08-06 19:55:07', NULL),
(3, 13, 'media', 'large', 'ABSPATHwp-content/uploads/2022/08/hero-img-1-1024x497.png', '', 'Уменьшено на 0,0% (108,0 Б)', 323893, 324001, '', 10, 0, 1, '2022-08-06 19:55:20', NULL),
(4, 13, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2022/08/hero-img-1-150x150.png', '', 'Уменьшено на 10,8% (2,5 КБ)', 21435, 24024, '', 10, 0, 1, '2022-08-06 19:55:21', NULL),
(5, 13, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2022/08/hero-img-1-768x373.png', '', 'Уменьшено на 0,0% (98,0 Б)', 200029, 200127, '', 10, 0, 1, '2022-08-06 19:55:33', NULL),
(6, 13, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2022/08/hero-img-1-1536x746.png', '', 'Уменьшено на 0,0% (228,0 Б)', 638279, 638507, '', 10, 0, 1, '2022-08-06 19:56:02', NULL) ;

#
# End of data contents of table `wp_ewwwio_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_queue`
#

DROP TABLE IF EXISTS `wp_ewwwio_queue`;


#
# Table structure of table `wp_ewwwio_queue`
#

CREATE TABLE `wp_ewwwio_queue` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint unsigned DEFAULT NULL,
  `gallery` varchar(20) DEFAULT NULL,
  `scanned` tinyint NOT NULL DEFAULT '0',
  `new` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


#
# Data contents of table `wp_ewwwio_queue`
#

#
# End of data contents of table `wp_ewwwio_queue`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://vateko.loc', 'yes'),
(2, 'home', 'http://vateko.loc', 'yes'),
(3, 'blogname', 'Эковата «ВАТЭКО» — безопасный утеплитель', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'gorlov35@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:111:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:11:"products/?$";s:27:"index.php?post_type=product";s:41:"products/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:36:"products/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:28:"products/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"products/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"products/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"products/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"products/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"products/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"products/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"products/(.+?)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:27:"products/(.+?)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:47:"products/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:42:"products/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:35:"products/(.+?)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:42:"products/(.+?)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:31:"products/(.+?)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:10:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:91:"all-in-one-wp-migration-unlimited-extension/all-in-one-wp-migration-unlimited-extension.php";i:3;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:4;s:22:"cyr2lat/cyr-to-lat.php";i:5;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:6;s:27:"redis-cache/redis-cache.php";i:7;s:21:"safe-svg/safe-svg.php";i:8;s:13:"soil/soil.php";i:9;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'vateko10', 'yes'),
(41, 'stylesheet', 'vateko10', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1675365155', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:14:"sidebar-footer";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:12:{i:1659813196;a:6:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1659813204;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1659813219;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1659813264;a:1:{s:28:"wp_update_comment_type_batch";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1659814126;a:1:{s:39:"ewww_image_optimizer_relative_migration";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:34:"ewwwio_relative_migration_interval";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1659814287;a:1:{s:26:"rediscache_discard_metrics";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1659882787;a:3:{s:38:"wpstg_q_ajax_support_feature_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:12:"wpstg_weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:20:"wpstg_queue_maintain";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"wpstg_daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:19:"wpstg_queue_process";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:12:"wpstg_hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1659882788;a:2:{s:18:"wpstg_weekly_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:17:"wpstg_daily_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1659889808;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"8e37d112eed2311de901b0df41a405d3";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:99;}}}}i:1659899596;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1659902238;a:1:{s:21:"ai1wm_storage_cleanup";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1659813230;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(120, 'can_compress_scripts', '1', 'no'),
(121, 'current_theme', 'Эковата «ВАТЭКО»', 'yes'),
(122, 'theme_mods_vateko10', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:2;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(123, 'theme_switched', '', 'yes'),
(124, 'recovery_mode_email_last_sent', '1659813230', 'yes'),
(125, 'recovery_keys', 'a:1:{s:22:"Up7W9JEuIqtXii2N0V83pK";a:2:{s:10:"hashed_key";s:34:"$P$BFdfepCiwOZ1JXcyNHcEHtiaQHkOPA0";s:10:"created_at";i:1659813230;}}', 'yes'),
(126, 'recently_activated', 'a:3:{s:63:"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php";i:1659890974;s:77:"wp-migrate-db-pro-theme-plugin-files/wp-migrate-db-pro-theme-plugin-files.php";i:1659890974;s:33:"wp-staging-pro/wp-staging-pro.php";i:1659890433;}', 'yes'),
(127, 'ewww_image_optimizer_relative_migration_status', 'done', 'yes'),
(129, 'acf_version', '5.12.2', 'yes'),
(130, 'ewww_image_optimizer_noauto', '', 'yes'),
(131, 'ewww_image_optimizer_disable_editor', '', 'yes'),
(132, 'ewww_image_optimizer_debug', '', 'yes'),
(133, 'ewww_image_optimizer_metadata_remove', '1', 'yes'),
(134, 'ewww_image_optimizer_jpg_level', '0', 'yes'),
(135, 'ewww_image_optimizer_png_level', '0', 'yes'),
(136, 'ewww_image_optimizer_gif_level', '0', 'yes'),
(137, 'ewww_image_optimizer_pdf_level', '0', 'yes'),
(138, 'ewww_image_optimizer_svg_level', '0', 'yes'),
(139, 'ewww_image_optimizer_jpg_quality', '100', 'yes'),
(140, 'ewww_image_optimizer_webp_quality', '100', 'yes'),
(141, 'ewww_image_optimizer_resize_existing', '1', 'yes'),
(142, 'ewww_image_optimizer_exactdn', '', 'yes'),
(144, 'exactdn_all_the_things', '1', 'yes'),
(145, 'exactdn_lossy', '1', 'yes'),
(146, 'exactdn_exclude', '', 'yes'),
(147, 'exactdn_sub_folder', '', 'no'),
(148, 'exactdn_prevent_db_queries', '', 'yes'),
(149, 'ewww_image_optimizer_lazy_load', '1', 'yes'),
(150, 'ewww_image_optimizer_use_siip', '', 'yes'),
(151, 'ewww_image_optimizer_use_lqip', '', 'yes'),
(152, 'ewww_image_optimizer_ll_exclude', '', 'yes'),
(153, 'ewww_image_optimizer_ll_all_things', '', 'yes'),
(154, 'ewww_image_optimizer_disable_pngout', '1', 'yes'),
(155, 'ewww_image_optimizer_disable_svgcleaner', '1', 'yes'),
(156, 'ewww_image_optimizer_optipng_level', '2', 'yes'),
(157, 'ewww_image_optimizer_pngout_level', '2', 'yes'),
(158, 'ewww_image_optimizer_webp_for_cdn', '1', 'yes'),
(159, 'ewww_image_optimizer_force_gif2webp', '', 'yes'),
(160, 'ewww_image_optimizer_picture_webp', '1', 'yes'),
(161, 'ewww_image_optimizer_webp_rewrite_exclude', '', 'yes'),
(163, 'ewww_image_optimizer_ll_autoscale', '1', 'no'),
(164, 'exactdn_never_been_active', '1', 'no'),
(165, 'ewww_image_optimizer_bulk_resume', '', 'yes'),
(166, 'ewww_image_optimizer_aux_resume', '', 'yes'),
(167, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(168, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(170, 'ewww_image_optimizer_review_time', '1660419151', 'no'),
(171, 'ewww_image_optimizer_version', '670', 'yes'),
(180, 'new_admin_email', 'gorlov35@gmail.com', 'yes'),
(181, 'ewww_image_optimizer_backup_files', '', 'no'),
(182, 'ewww_image_optimizer_wizard_complete', '1', 'no'),
(183, 'ewww_image_optimizer_local_mode', '1', 'yes'),
(184, 'ewww_image_optimizer_avif_quality', '', 'yes'),
(185, 'ewww_image_optimizer_aux_paths', '', 'yes'),
(186, 'ewww_image_optimizer_exclude_paths', '', 'yes'),
(187, 'ewww_image_optimizer_maxmediawidth', '0', 'yes'),
(188, 'ewww_image_optimizer_maxmediaheight', '0', 'yes'),
(189, 'ewww_image_optimizer_disable_resizes', '', 'yes'),
(190, 'ewww_image_optimizer_disable_resizes_opt', '', 'yes'),
(191, 'ewww_image_optimizer_jpg_background', '', 'yes'),
(192, 'ewww_image_optimizer_webp', '1', 'yes'),
(193, 'ewww_image_optimizer_webp_force', '1', 'yes'),
(194, 'ewww_image_optimizer_webp_paths', '', 'yes'),
(195, 'ewww_image_optimizer_sharpen', '1', 'yes'),
(196, 'ewww_image_optimizer_include_media_paths', '1', 'yes'),
(197, 'ewww_image_optimizer_resize_detection', '1', 'yes'),
(198, 'ai1wm_secret_key', '0f2vak4SwDc0', 'yes'),
(199, 'options_logo_image', '18', 'yes'),
(200, '_options_logo_image', 'field_Настройки_темы_logo_image', 'yes'),
(201, 'options_email', 'ecovata@gmail.com', 'yes'),
(202, '_options_email', 'field_Настройки_темы_email', 'yes'),
(203, 'options_phone', '+ 7 (999) 888-77-66', 'yes'),
(204, '_options_phone', 'field_Настройки_темы_phone', 'yes'),
(205, 'options_copyright', '2020-2021 г. © <span>Все права защищены.</span>', 'yes'),
(206, '_options_copyright', 'field_Настройки_темы_copyright', 'yes'),
(207, 'options_vk_url', '', 'yes'),
(208, '_options_vk_url', 'field_Настройки_темы_vk_url', 'yes'),
(209, 'options_telegram_url', '', 'yes'),
(210, '_options_telegram_url', 'field_Настройки_темы_telegram_url', 'yes'),
(211, 'options_whatsup_url', '', 'yes'),
(212, '_options_whatsup_url', 'field_Настройки_темы_whatsup_url', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(213, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(214, 'ai1wm_status', 'a:2:{s:4:"type";s:8:"download";s:7:"message";s:307:"<a href="http://vateko.loc/wp-content/ai1wm-backups/vateko.loc-20220807-163902-sh0kl9.wpress" class="ai1wm-button-green ai1wm-emphasize ai1wm-button-download" title="vateko.loc" download="vateko.loc-20220807-163902-sh0kl9.wpress"><span>Загрузить vateko.loc</span><em>Размер: 253 КБ</em></a>";}', 'yes'),
(216, 'wpstg_license_key', '******************', 'yes'),
(217, 'wpstg_license_status', 'O:8:"stdClass":2:{s:7:"license";s:5:"valid";s:7:"expires";s:10:"2040-10-10";}', 'yes'),
(218, 'wpstg_settings', 'a:8:{s:17:"lastAnalyticsSend";i:1659890187;s:10:"queryLimit";s:5:"10000";s:12:"querySRLimit";s:5:"20000";s:9:"fileLimit";s:2:"50";s:7:"cpuLoad";s:3:"low";s:9:"batchSize";s:1:"2";s:11:"maxFileSize";s:1:"8";s:9:"optimizer";s:1:"1";}', 'yes'),
(219, 'wpstg_installDate', '2022-08-07 02:33:08', 'yes'),
(220, 'wpstg_missing_cloneName_routine_executed', '1', 'yes'),
(221, 'wpstgpro_version', '4.2.10', 'yes'),
(222, 'wpstgpro_version_upgraded_from', '', 'yes'),
(223, 'wpstg_access_token', 'XgMUdlNrWp1suQAyQnPjS1IqAdoSwmysX9q5SjWX9dgKyCYmcjcHQHBIdCm4nTv5', 'yes'),
(224, 'wpstg_analytics_notice_dismissed', '1', 'no'),
(225, 'wpstg_analytics_has_consent', '0', 'no'),
(226, 'wpstg_analytics_event_62b01f175393', '{"event":"event_backup_create","job_identifier":"62b01f175393","event_hash":"1659883367.3391521414164","is_finished":true,"is_stale":false,"is_error":false,"is_cancelled":false,"is_requirement_check_fail":false,"requirement_fail_reason":"","error_message":null,"last_debug_logs":null,"ready_to_send":true,"start_time":1659883367,"end_time":1659883444,"duration":77,"site_info":{"is_staging_site":0,"db_copy_query_limit":"10000","db_sr_limit":"20000","file_copy_limit":"50","cpu_priority":"low","file_copy_batch_size":"2","max_file_size":"8","optimizer":"1","keep_permalinks":false,"disable_admin_login":false,"delay_between_requests":0,"debug_mode":false,"remove_data_on_uninstall":false,"check_directory_size":false,"access_permission":[],"users_with_staging_access":"","php_version":"7.4.30","blog_id":1,"network_id":1,"single_or_multi":"single","wpstaging_free_or_pro":"pro","wpstaging_version":"4.2.10","operating_system_family":"UNIX","operating_system_family_raw":"Linux","active_theme":"vateko10","wordpress_version":"6.0.1","wpdb_version":53496,"db_collate":"utf8mb4_unicode_520_ci","db_charset":"utf8mb4","sql_server_version_number":"8.0.29","sql_server_version_engine":"UNDEFINED","sql_server_version_engine_raw":"8.0.29","site_active_plugins":{"wp-staging-pro\\/wp-staging-pro.php":"4.2.10"},"mu_plugins":{"wp-migrate-db-pro-compatibility.php":"1.2","wp-staging-optimizer.php":"1.5.1"},"network_active_plugins":[],"php_extensions":["Core","date","libxml","openssl","pcre","sqlite3","zlib","ctype","curl","dom","fileinfo","filter","ftp","hash","iconv","json","mbstring","SPL","PDO","pdo_sqlite","bz2","posix","readline","Reflection","session","SimpleXML","standard","tokenizer","xml","xmlreader","xmlwriter","mysqlnd","cgi-fcgi","bcmath","Phar","gd","imagick","intl","mysqli","pdo_mysql","pdo_pgsql","redis","sodium","xmlrpc","xsl","zip","Zend OPcache","xdebug"]},"is_backup_database":true,"is_backup_plugins":true,"is_backup_themes":true,"is_backup_uploads":true,"is_backup_muplugins":true,"is_backup_wp_content":true,"automated_backup":0,"filesystem_size":462289947,"database_size":231323,"discovered_files":42025}', 'no'),
(227, 'wpstg_last_backup_info', 'a:3:{s:7:"endTime";i:1659883444;s:8:"duration";i:0;s:16:"JobExportDataDto";O:45:"WPStaging\\Pro\\Backup\\Dto\\Job\\JobExportDataDto":0:{}}', 'no'),
(235, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1659911384;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=646 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_edit_lock', '1659820404:1'),
(4, 5, '_edit_lock', '1659813965:1'),
(5, 6, '_edit_lock', '1659814576:1'),
(6, 2, '_edit_lock', '1659911328:1'),
(7, 7, '_edit_lock', '1659814682:1'),
(8, 8, '_edit_lock', '1659816136:1'),
(9, 2, '_edit_last', '1'),
(10, 12, '_wp_attached_file', '2022/08/bigbuckbunny-1.mp4'),
(11, 12, '_wp_attachment_metadata', 'a:10:{s:8:"filesize";i:59228650;s:9:"mime_type";s:9:"video/mp4";s:6:"length";i:596;s:16:"length_formatted";s:4:"9:56";s:5:"width";i:1280;s:6:"height";i:720;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:9:"quicktime";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:44100;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}s:17:"created_timestamp";i:-2082844800;}'),
(12, 13, '_wp_attached_file', '2022/08/hero-img-1.png'),
(13, 13, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1680;s:6:"height";i:816;s:4:"file";s:22:"2022/08/hero-img-1.png";s:8:"filesize";i:1003797;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:22:"hero-img-1-300x146.png";s:5:"width";i:300;s:6:"height";i:146;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44140;}s:5:"large";a:5:{s:4:"file";s:23:"hero-img-1-1024x497.png";s:5:"width";i:1024;s:6:"height";i:497;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:323893;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"hero-img-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21435;}s:12:"medium_large";a:5:{s:4:"file";s:22:"hero-img-1-768x373.png";s:5:"width";i:768;s:6:"height";i:373;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:200029;}s:9:"1536x1536";a:5:{s:4:"file";s:23:"hero-img-1-1536x746.png";s:5:"width";i:1536;s:6:"height";i:746;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:638279;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 16, '_wp_attached_file', '2022/08/about-img-1.png'),
(15, 16, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:798;s:6:"height";i:582;s:4:"file";s:23:"2022/08/about-img-1.png";s:8:"filesize";i:782095;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"about-img-1-300x219.png";s:5:"width";i:300;s:6:"height";i:219;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:128296;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"about-img-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46357;}s:12:"medium_large";a:5:{s:4:"file";s:23:"about-img-1-768x560.png";s:5:"width";i:768;s:6:"height";i:560;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:717742;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(16, 18, '_wp_attached_file', '2022/08/logo-1.svg'),
(17, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:118;s:6:"height";i:39;s:4:"file";s:18:"2022/08/logo-1.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:10:"logo-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:10:"logo-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:10:"logo-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:10:"logo-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:10:"logo-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:10:"logo-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:13544;}}s:8:"filesize";i:13544;}'),
(18, 19, '_menu_item_type', 'custom'),
(19, 19, '_menu_item_menu_item_parent', '0'),
(20, 19, '_menu_item_object_id', '19'),
(21, 19, '_menu_item_object', 'custom'),
(22, 19, '_menu_item_target', ''),
(23, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(24, 19, '_menu_item_xfn', ''),
(25, 19, '_menu_item_url', 'http://№'),
(27, 20, '_menu_item_type', 'custom'),
(28, 20, '_menu_item_menu_item_parent', '0'),
(29, 20, '_menu_item_object_id', '20'),
(30, 20, '_menu_item_object', 'custom'),
(31, 20, '_menu_item_target', ''),
(32, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(33, 20, '_menu_item_xfn', ''),
(34, 20, '_menu_item_url', '#'),
(36, 21, '_menu_item_type', 'custom'),
(37, 21, '_menu_item_menu_item_parent', '0'),
(38, 21, '_menu_item_object_id', '21'),
(39, 21, '_menu_item_object', 'custom'),
(40, 21, '_menu_item_target', ''),
(41, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(42, 21, '_menu_item_xfn', ''),
(43, 21, '_menu_item_url', '#'),
(45, 22, '_menu_item_type', 'custom'),
(46, 22, '_menu_item_menu_item_parent', '0'),
(47, 22, '_menu_item_object_id', '22'),
(48, 22, '_menu_item_object', 'custom'),
(49, 22, '_menu_item_target', ''),
(50, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(51, 22, '_menu_item_xfn', ''),
(52, 22, '_menu_item_url', '#'),
(54, 23, '_menu_item_type', 'custom'),
(55, 23, '_menu_item_menu_item_parent', '0'),
(56, 23, '_menu_item_object_id', '23'),
(57, 23, '_menu_item_object', 'custom'),
(58, 23, '_menu_item_target', ''),
(59, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(60, 23, '_menu_item_xfn', ''),
(61, 23, '_menu_item_url', '#'),
(63, 29, '_edit_lock', '1659820281:1'),
(64, 30, '_edit_lock', '1659820317:1'),
(65, 31, '_edit_lock', '1659820308:1'),
(66, 32, '_edit_lock', '1659820433:1'),
(67, 33, '_edit_lock', '1659820381:1'),
(68, 34, '_edit_lock', '1659820461:1'),
(69, 35, '_edit_lock', '1659867094:1'),
(70, 36, '_edit_lock', '1659820534:1'),
(71, 35, '_edit_last', '1'),
(72, 35, 'features', '2'),
(73, 35, '_features', 'field_product_extra_features'),
(74, 37, 'features', ''),
(75, 37, '_features', 'field_product_extra_features'),
(80, 35, 'features_0_features_icon', '74'),
(81, 35, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(82, 35, 'features_0_features_title', 'Размер мешка'),
(83, 35, '_features_0_features_title', 'field_product_extra_features_features_title'),
(84, 35, 'features_0_features_value', '750х460х360 мм'),
(85, 35, '_features_0_features_value', 'field_product_extra_features_features_value'),
(86, 35, 'features_1_features_icon', '75'),
(87, 35, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(88, 35, 'features_1_features_title', 'Вес мешка'),
(89, 35, '_features_1_features_title', 'field_product_extra_features_features_title'),
(90, 35, 'features_1_features_value', '15 кг'),
(91, 35, '_features_1_features_value', 'field_product_extra_features_features_value'),
(92, 41, 'features', '2'),
(93, 41, '_features', 'field_product_extra_features'),
(94, 41, 'features_0_features_icon', '39'),
(95, 41, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(96, 41, 'features_0_features_title', 'Размер мешка'),
(97, 41, '_features_0_features_title', 'field_product_extra_features_features_title'),
(98, 41, 'features_0_features_value', '750х460х360 мм'),
(99, 41, '_features_0_features_value', 'field_product_extra_features_features_value'),
(100, 41, 'features_1_features_icon', '40'),
(101, 41, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(102, 41, 'features_1_features_title', 'Вес мешка'),
(103, 41, '_features_1_features_title', 'field_product_extra_features_features_title'),
(104, 41, 'features_1_features_value', '15 кг'),
(105, 41, '_features_1_features_value', 'field_product_extra_features_features_value'),
(106, 42, '_edit_lock', '1659867591:1'),
(107, 43, '_edit_lock', '1659821532:1'),
(108, 45, '_edit_lock', '1659867576:1'),
(109, 42, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(110, 42, 'features_0_features_icon', '85'),
(111, 42, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(112, 42, 'features_0_features_title', 'Размер мешка '),
(113, 42, '_features_0_features_title', 'field_product_extra_features_features_title'),
(114, 42, 'features_0_features_value', '750х460х360 мм'),
(115, 42, '_features_0_features_value', 'field_product_extra_features_features_value'),
(116, 42, 'features_1_features_icon', '78'),
(117, 42, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(118, 42, 'features_1_features_title', 'Вес мешка 15 кг'),
(119, 42, '_features_1_features_title', 'field_product_extra_features_features_title'),
(120, 42, 'features_1_features_value', '15 кг'),
(121, 42, '_features_1_features_value', 'field_product_extra_features_features_value'),
(122, 42, 'features', '2'),
(123, 42, '_features', 'field_product_extra_features'),
(124, 46, 'features_0_features_icon', '39'),
(125, 46, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(126, 46, 'features_0_features_title', 'Размер мешка '),
(127, 46, '_features_0_features_title', 'field_product_extra_features_features_title'),
(128, 46, 'features_0_features_value', '750х460х360 мм'),
(129, 46, '_features_0_features_value', 'field_product_extra_features_features_value'),
(130, 46, 'features_1_features_icon', '40'),
(131, 46, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(132, 46, 'features_1_features_title', 'Вес мешка 15 кг'),
(133, 46, '_features_1_features_title', 'field_product_extra_features_features_title'),
(134, 46, 'features_1_features_value', '15 кг'),
(135, 46, '_features_1_features_value', 'field_product_extra_features_features_value'),
(136, 46, 'features', '2'),
(137, 46, '_features', 'field_product_extra_features'),
(138, 48, 'features', '2'),
(139, 48, '_features', 'field_product_extra_features'),
(140, 48, 'features_0_features_icon', '39'),
(141, 48, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(142, 48, 'features_0_features_title', 'Размер мешка'),
(143, 48, '_features_0_features_title', 'field_product_extra_features_features_title'),
(144, 48, 'features_0_features_value', '750х460х360 мм'),
(145, 48, '_features_0_features_value', 'field_product_extra_features_features_value'),
(146, 48, 'features_1_features_icon', '40'),
(147, 48, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(148, 48, 'features_1_features_title', 'Вес мешка'),
(149, 48, '_features_1_features_title', 'field_product_extra_features_features_title'),
(150, 48, 'features_1_features_value', '15 кг'),
(151, 48, '_features_1_features_value', 'field_product_extra_features_features_value'),
(152, 49, '_edit_lock', '1659821811:1'),
(157, 45, '_edit_last', '1'),
(158, 45, 'features_0_features_icon', '81'),
(159, 45, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(160, 45, 'features_0_features_title', 'Ячейка сетки'),
(161, 45, '_features_0_features_title', 'field_product_extra_features_features_title'),
(162, 45, 'features_0_features_value', '15х25 мм'),
(163, 45, '_features_0_features_value', 'field_product_extra_features_features_value'),
(164, 45, 'features_1_features_icon', '82'),
(165, 45, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(166, 45, 'features_1_features_title', 'Размер рулона'),
(167, 45, '_features_1_features_title', 'field_product_extra_features_features_title'),
(168, 45, 'features_1_features_value', '20 м<sup>2</sup>'),
(169, 45, '_features_1_features_value', 'field_product_extra_features_features_value'),
(170, 45, 'features', '2'),
(171, 45, '_features', 'field_product_extra_features'),
(172, 53, 'features_0_features_icon', '50'),
(173, 53, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(174, 53, 'features_0_features_title', 'Ячейка сетки 15х25 мм'),
(175, 53, '_features_0_features_title', 'field_product_extra_features_features_title'),
(176, 53, 'features_0_features_value', '15х25 мм'),
(177, 53, '_features_0_features_value', 'field_product_extra_features_features_value'),
(178, 53, 'features_1_features_icon', '51'),
(179, 53, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(180, 53, 'features_1_features_title', 'Размер рулона 20 м2'),
(181, 53, '_features_1_features_title', 'field_product_extra_features_features_title'),
(182, 53, 'features_1_features_value', '20 м<sup>2</sup>'),
(183, 53, '_features_1_features_value', 'field_product_extra_features_features_value'),
(184, 53, 'features', '2'),
(185, 53, '_features', 'field_product_extra_features'),
(186, 54, 'features', '2'),
(187, 54, '_features', 'field_product_extra_features'),
(188, 54, 'features_0_features_icon', '39'),
(189, 54, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(190, 54, 'features_0_features_title', 'Размер мешка'),
(191, 54, '_features_0_features_title', 'field_product_extra_features_features_title'),
(192, 54, 'features_0_features_value', '750х460х360 мм'),
(193, 54, '_features_0_features_value', 'field_product_extra_features_features_value'),
(194, 54, 'features_1_features_icon', '40'),
(195, 54, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(196, 54, 'features_1_features_title', 'Вес мешка'),
(197, 54, '_features_1_features_title', 'field_product_extra_features_features_title'),
(198, 54, 'features_1_features_value', '15 кг'),
(199, 54, '_features_1_features_value', 'field_product_extra_features_features_value'),
(200, 55, 'features_0_features_icon', '39'),
(201, 55, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(202, 55, 'features_0_features_title', 'Размер мешка '),
(203, 55, '_features_0_features_title', 'field_product_extra_features_features_title'),
(204, 55, 'features_0_features_value', '750х460х360 мм'),
(205, 55, '_features_0_features_value', 'field_product_extra_features_features_value'),
(206, 55, 'features_1_features_icon', '40'),
(207, 55, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(208, 55, 'features_1_features_title', 'Вес мешка 15 кг'),
(209, 55, '_features_1_features_title', 'field_product_extra_features_features_title'),
(210, 55, 'features_1_features_value', '15 кг'),
(211, 55, '_features_1_features_value', 'field_product_extra_features_features_value'),
(212, 55, 'features', '2'),
(213, 55, '_features', 'field_product_extra_features') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(214, 35, 'product_price', '55₽ / кг'),
(215, 35, '_product_price', 'field_product_extra_product_price'),
(216, 56, 'features', '2'),
(217, 56, '_features', 'field_product_extra_features'),
(218, 56, 'features_0_features_icon', '39'),
(219, 56, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(220, 56, 'features_0_features_title', 'Размер мешка'),
(221, 56, '_features_0_features_title', 'field_product_extra_features_features_title'),
(222, 56, 'features_0_features_value', '750х460х360 мм'),
(223, 56, '_features_0_features_value', 'field_product_extra_features_features_value'),
(224, 56, 'features_1_features_icon', '40'),
(225, 56, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(226, 56, 'features_1_features_title', 'Вес мешка'),
(227, 56, '_features_1_features_title', 'field_product_extra_features_features_title'),
(228, 56, 'features_1_features_value', '15 кг'),
(229, 56, '_features_1_features_value', 'field_product_extra_features_features_value'),
(230, 56, 'product_price', 'product'),
(231, 56, '_product_price', 'field_product_extra_product_price'),
(232, 42, 'product_price', '35₽ / кг'),
(233, 42, '_product_price', 'field_product_extra_product_price'),
(234, 57, 'features_0_features_icon', '39'),
(235, 57, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(236, 57, 'features_0_features_title', 'Размер мешка '),
(237, 57, '_features_0_features_title', 'field_product_extra_features_features_title'),
(238, 57, 'features_0_features_value', '750х460х360 мм'),
(239, 57, '_features_0_features_value', 'field_product_extra_features_features_value'),
(240, 57, 'features_1_features_icon', '40'),
(241, 57, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(242, 57, 'features_1_features_title', 'Вес мешка 15 кг'),
(243, 57, '_features_1_features_title', 'field_product_extra_features_features_title'),
(244, 57, 'features_1_features_value', '15 кг'),
(245, 57, '_features_1_features_value', 'field_product_extra_features_features_value'),
(246, 57, 'features', '2'),
(247, 57, '_features', 'field_product_extra_features'),
(248, 57, 'product_price', '35₽ / кг'),
(249, 57, '_product_price', 'field_product_extra_product_price'),
(250, 45, 'product_price', '2 700₽ / рулон'),
(251, 45, '_product_price', 'field_product_extra_product_price'),
(252, 58, 'features_0_features_icon', '50'),
(253, 58, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(254, 58, 'features_0_features_title', 'Ячейка сетки 15х25 мм'),
(255, 58, '_features_0_features_title', 'field_product_extra_features_features_title'),
(256, 58, 'features_0_features_value', '15х25 мм'),
(257, 58, '_features_0_features_value', 'field_product_extra_features_features_value'),
(258, 58, 'features_1_features_icon', '51'),
(259, 58, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(260, 58, 'features_1_features_title', 'Размер рулона 20 м2'),
(261, 58, '_features_1_features_title', 'field_product_extra_features_features_title'),
(262, 58, 'features_1_features_value', '20 м<sup>2</sup>'),
(263, 58, '_features_1_features_value', 'field_product_extra_features_features_value'),
(264, 58, 'features', '2'),
(265, 58, '_features', 'field_product_extra_features'),
(266, 58, 'product_price', '2 700₽ / рулон'),
(267, 58, '_product_price', 'field_product_extra_product_price'),
(268, 59, 'features', '2'),
(269, 59, '_features', 'field_product_extra_features'),
(270, 59, 'features_0_features_icon', '39'),
(271, 59, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(272, 59, 'features_0_features_title', 'Размер мешка'),
(273, 59, '_features_0_features_title', 'field_product_extra_features_features_title'),
(274, 59, 'features_0_features_value', '750х460х360 мм'),
(275, 59, '_features_0_features_value', 'field_product_extra_features_features_value'),
(276, 59, 'features_1_features_icon', '40'),
(277, 59, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(278, 59, 'features_1_features_title', 'Вес мешка'),
(279, 59, '_features_1_features_title', 'field_product_extra_features_features_title'),
(280, 59, 'features_1_features_value', '15 кг'),
(281, 59, '_features_1_features_value', 'field_product_extra_features_features_value'),
(282, 59, 'product_price', '55₽ / кг'),
(283, 59, '_product_price', 'field_product_extra_product_price'),
(284, 35, 'product_button-text', 'Рассчитать количество Эковаты'),
(285, 35, '_product_button-text', 'field_product_extra_product_button-text'),
(286, 60, 'features', '2'),
(287, 60, '_features', 'field_product_extra_features'),
(288, 60, 'features_0_features_icon', '39'),
(289, 60, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(290, 60, 'features_0_features_title', 'Размер мешка'),
(291, 60, '_features_0_features_title', 'field_product_extra_features_features_title'),
(292, 60, 'features_0_features_value', '750х460х360 мм'),
(293, 60, '_features_0_features_value', 'field_product_extra_features_features_value'),
(294, 60, 'features_1_features_icon', '40'),
(295, 60, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(296, 60, 'features_1_features_title', 'Вес мешка'),
(297, 60, '_features_1_features_title', 'field_product_extra_features_features_title'),
(298, 60, 'features_1_features_value', '15 кг'),
(299, 60, '_features_1_features_value', 'field_product_extra_features_features_value'),
(300, 60, 'product_price', '55₽ / кг'),
(301, 60, '_product_price', 'field_product_extra_product_price'),
(302, 60, 'product_button-text', 'Рассчитать количество Эковаты'),
(303, 60, '_product_button-text', 'field_product_extra_product_button-text'),
(304, 42, 'product_button-text', 'Заказать Мульчу'),
(305, 42, '_product_button-text', 'field_product_extra_product_button-text'),
(306, 61, 'features_0_features_icon', '39'),
(307, 61, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(308, 61, 'features_0_features_title', 'Размер мешка '),
(309, 61, '_features_0_features_title', 'field_product_extra_features_features_title'),
(310, 61, 'features_0_features_value', '750х460х360 мм'),
(311, 61, '_features_0_features_value', 'field_product_extra_features_features_value'),
(312, 61, 'features_1_features_icon', '40'),
(313, 61, '_features_1_features_icon', 'field_product_extra_features_features_icon') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(314, 61, 'features_1_features_title', 'Вес мешка 15 кг'),
(315, 61, '_features_1_features_title', 'field_product_extra_features_features_title'),
(316, 61, 'features_1_features_value', '15 кг'),
(317, 61, '_features_1_features_value', 'field_product_extra_features_features_value'),
(318, 61, 'features', '2'),
(319, 61, '_features', 'field_product_extra_features'),
(320, 61, 'product_price', '35₽ / кг'),
(321, 61, '_product_price', 'field_product_extra_product_price'),
(322, 61, 'product_button-text', 'Заказать Мульчу'),
(323, 61, '_product_button-text', 'field_product_extra_product_button-text'),
(324, 35, 'product_button_text', 'Рассчитать количество Эковаты'),
(325, 35, '_product_button_text', 'field_product_extra_product_button_text'),
(326, 62, 'features', '2'),
(327, 62, '_features', 'field_product_extra_features'),
(328, 62, 'features_0_features_icon', '39'),
(329, 62, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(330, 62, 'features_0_features_title', 'Размер мешка'),
(331, 62, '_features_0_features_title', 'field_product_extra_features_features_title'),
(332, 62, 'features_0_features_value', '750х460х360 мм'),
(333, 62, '_features_0_features_value', 'field_product_extra_features_features_value'),
(334, 62, 'features_1_features_icon', '40'),
(335, 62, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(336, 62, 'features_1_features_title', 'Вес мешка'),
(337, 62, '_features_1_features_title', 'field_product_extra_features_features_title'),
(338, 62, 'features_1_features_value', '15 кг'),
(339, 62, '_features_1_features_value', 'field_product_extra_features_features_value'),
(340, 62, 'product_price', '55₽ / кг'),
(341, 62, '_product_price', 'field_product_extra_product_price'),
(342, 62, 'product_button-text', 'Рассчитать количество Эковаты'),
(343, 62, '_product_button-text', 'field_product_extra_product_button-text'),
(344, 62, 'product_button_text', 'Рассчитать количество Эковаты'),
(345, 62, '_product_button_text', 'field_product_extra_product_button_text'),
(346, 42, 'product_button_text', 'Заказать Мульчу'),
(347, 42, '_product_button_text', 'field_product_extra_product_button_text'),
(348, 63, 'features_0_features_icon', '39'),
(349, 63, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(350, 63, 'features_0_features_title', 'Размер мешка '),
(351, 63, '_features_0_features_title', 'field_product_extra_features_features_title'),
(352, 63, 'features_0_features_value', '750х460х360 мм'),
(353, 63, '_features_0_features_value', 'field_product_extra_features_features_value'),
(354, 63, 'features_1_features_icon', '40'),
(355, 63, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(356, 63, 'features_1_features_title', 'Вес мешка 15 кг'),
(357, 63, '_features_1_features_title', 'field_product_extra_features_features_title'),
(358, 63, 'features_1_features_value', '15 кг'),
(359, 63, '_features_1_features_value', 'field_product_extra_features_features_value'),
(360, 63, 'features', '2'),
(361, 63, '_features', 'field_product_extra_features'),
(362, 63, 'product_price', '35₽ / кг'),
(363, 63, '_product_price', 'field_product_extra_product_price'),
(364, 63, 'product_button-text', 'Заказать Мульчу'),
(365, 63, '_product_button-text', 'field_product_extra_product_button-text'),
(366, 63, 'product_button_text', 'Заказать Мульчу'),
(367, 63, '_product_button_text', 'field_product_extra_product_button_text'),
(368, 45, 'product_button_text', 'Заказать сетку'),
(369, 45, '_product_button_text', 'field_product_extra_product_button_text'),
(370, 64, 'features_0_features_icon', '50'),
(371, 64, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(372, 64, 'features_0_features_title', 'Ячейка сетки 15х25 мм'),
(373, 64, '_features_0_features_title', 'field_product_extra_features_features_title'),
(374, 64, 'features_0_features_value', '15х25 мм'),
(375, 64, '_features_0_features_value', 'field_product_extra_features_features_value'),
(376, 64, 'features_1_features_icon', '51'),
(377, 64, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(378, 64, 'features_1_features_title', 'Размер рулона 20 м2'),
(379, 64, '_features_1_features_title', 'field_product_extra_features_features_title'),
(380, 64, 'features_1_features_value', '20 м<sup>2</sup>'),
(381, 64, '_features_1_features_value', 'field_product_extra_features_features_value'),
(382, 64, 'features', '2'),
(383, 64, '_features', 'field_product_extra_features'),
(384, 64, 'product_price', '2 700₽ / рулон'),
(385, 64, '_product_price', 'field_product_extra_product_price'),
(386, 64, 'product_button_text', 'Зказать сетку'),
(387, 64, '_product_button_text', 'field_product_extra_product_button_text'),
(388, 65, 'features_0_features_icon', '50'),
(389, 65, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(390, 65, 'features_0_features_title', 'Ячейка сетки'),
(391, 65, '_features_0_features_title', 'field_product_extra_features_features_title'),
(392, 65, 'features_0_features_value', '15х25 мм'),
(393, 65, '_features_0_features_value', 'field_product_extra_features_features_value'),
(394, 65, 'features_1_features_icon', '51'),
(395, 65, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(396, 65, 'features_1_features_title', 'Размер рулона'),
(397, 65, '_features_1_features_title', 'field_product_extra_features_features_title'),
(398, 65, 'features_1_features_value', '20 м<sup>2</sup>'),
(399, 65, '_features_1_features_value', 'field_product_extra_features_features_value'),
(400, 65, 'features', '2'),
(401, 65, '_features', 'field_product_extra_features'),
(402, 65, 'product_price', '2 700₽ / рулон'),
(403, 65, '_product_price', 'field_product_extra_product_price'),
(404, 65, 'product_button_text', 'Зказать сетку'),
(405, 65, '_product_button_text', 'field_product_extra_product_button_text'),
(406, 66, 'features_0_features_icon', '50'),
(407, 66, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(408, 66, 'features_0_features_title', 'Ячейка сетки'),
(409, 66, '_features_0_features_title', 'field_product_extra_features_features_title'),
(410, 66, 'features_0_features_value', '15х25 мм'),
(411, 66, '_features_0_features_value', 'field_product_extra_features_features_value'),
(412, 66, 'features_1_features_icon', '51'),
(413, 66, '_features_1_features_icon', 'field_product_extra_features_features_icon') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(414, 66, 'features_1_features_title', 'Размер рулона'),
(415, 66, '_features_1_features_title', 'field_product_extra_features_features_title'),
(416, 66, 'features_1_features_value', '20 м<sup>2</sup>'),
(417, 66, '_features_1_features_value', 'field_product_extra_features_features_value'),
(418, 66, 'features', '2'),
(419, 66, '_features', 'field_product_extra_features'),
(420, 66, 'product_price', '2 700₽ / рулон'),
(421, 66, '_product_price', 'field_product_extra_product_price'),
(422, 66, 'product_button_text', 'Заказать сетку'),
(423, 66, '_product_button_text', 'field_product_extra_product_button_text'),
(428, 69, 'features', '2'),
(429, 69, '_features', 'field_product_extra_features'),
(430, 69, 'features_0_features_icon', '68'),
(431, 69, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(432, 69, 'features_0_features_title', 'Размер мешка'),
(433, 69, '_features_0_features_title', 'field_product_extra_features_features_title'),
(434, 69, 'features_0_features_value', '750х460х360 мм'),
(435, 69, '_features_0_features_value', 'field_product_extra_features_features_value'),
(436, 69, 'features_1_features_icon', ''),
(437, 69, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(438, 69, 'features_1_features_title', 'Вес мешка'),
(439, 69, '_features_1_features_title', 'field_product_extra_features_features_title'),
(440, 69, 'features_1_features_value', '15 кг'),
(441, 69, '_features_1_features_value', 'field_product_extra_features_features_value'),
(442, 69, 'product_price', '55₽ / кг'),
(443, 69, '_product_price', 'field_product_extra_product_price'),
(444, 69, 'product_button-text', 'Рассчитать количество Эковаты'),
(445, 69, '_product_button-text', 'field_product_extra_product_button-text'),
(446, 69, 'product_button_text', 'Рассчитать количество Эковаты'),
(447, 69, '_product_button_text', 'field_product_extra_product_button_text'),
(450, 71, 'features', '2'),
(451, 71, '_features', 'field_product_extra_features'),
(452, 71, 'features_0_features_icon', '68'),
(453, 71, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(454, 71, 'features_0_features_title', 'Размер мешка'),
(455, 71, '_features_0_features_title', 'field_product_extra_features_features_title'),
(456, 71, 'features_0_features_value', '750х460х360 мм'),
(457, 71, '_features_0_features_value', 'field_product_extra_features_features_value'),
(458, 71, 'features_1_features_icon', '70'),
(459, 71, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(460, 71, 'features_1_features_title', 'Вес мешка'),
(461, 71, '_features_1_features_title', 'field_product_extra_features_features_title'),
(462, 71, 'features_1_features_value', '15 кг'),
(463, 71, '_features_1_features_value', 'field_product_extra_features_features_value'),
(464, 71, 'product_price', '55₽ / кг'),
(465, 71, '_product_price', 'field_product_extra_product_price'),
(466, 71, 'product_button-text', 'Рассчитать количество Эковаты'),
(467, 71, '_product_button-text', 'field_product_extra_product_button-text'),
(468, 71, 'product_button_text', 'Рассчитать количество Эковаты'),
(469, 71, '_product_button_text', 'field_product_extra_product_button_text'),
(472, 73, 'features', '2'),
(473, 73, '_features', 'field_product_extra_features'),
(474, 73, 'features_0_features_icon', '72'),
(475, 73, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(476, 73, 'features_0_features_title', 'Размер мешка'),
(477, 73, '_features_0_features_title', 'field_product_extra_features_features_title'),
(478, 73, 'features_0_features_value', '750х460х360 мм'),
(479, 73, '_features_0_features_value', 'field_product_extra_features_features_value'),
(480, 73, 'features_1_features_icon', ''),
(481, 73, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(482, 73, 'features_1_features_title', 'Вес мешка'),
(483, 73, '_features_1_features_title', 'field_product_extra_features_features_title'),
(484, 73, 'features_1_features_value', '15 кг'),
(485, 73, '_features_1_features_value', 'field_product_extra_features_features_value'),
(486, 73, 'product_price', '55₽ / кг'),
(487, 73, '_product_price', 'field_product_extra_product_price'),
(488, 73, 'product_button-text', 'Рассчитать количество Эковаты'),
(489, 73, '_product_button-text', 'field_product_extra_product_button-text'),
(490, 73, 'product_button_text', 'Рассчитать количество Эковаты'),
(491, 73, '_product_button_text', 'field_product_extra_product_button_text'),
(492, 74, '_wp_attached_file', '2022/08/product-size-icon-1.svg'),
(493, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:39;s:6:"height";i:47;s:4:"file";s:31:"2022/08/product-size-icon-1.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:23:"product-size-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9005;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:23:"product-size-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9005;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:23:"product-size-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9005;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:23:"product-size-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9005;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:23:"product-size-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9005;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:23:"product-size-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9005;}}s:8:"filesize";i:9005;}'),
(494, 75, '_wp_attached_file', '2022/08/product-weight-icon-1.svg'),
(495, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:45;s:6:"height";i:45;s:4:"file";s:33:"2022/08/product-weight-icon-1.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:25:"product-weight-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3110;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:25:"product-weight-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3110;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:25:"product-weight-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3110;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:25:"product-weight-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3110;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:25:"product-weight-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3110;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:25:"product-weight-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3110;}}s:8:"filesize";i:3110;}'),
(496, 76, 'features', '2'),
(497, 76, '_features', 'field_product_extra_features'),
(498, 76, 'features_0_features_icon', '74'),
(499, 76, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(500, 76, 'features_0_features_title', 'Размер мешка'),
(501, 76, '_features_0_features_title', 'field_product_extra_features_features_title'),
(502, 76, 'features_0_features_value', '750х460х360 мм'),
(503, 76, '_features_0_features_value', 'field_product_extra_features_features_value'),
(504, 76, 'features_1_features_icon', '75'),
(505, 76, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(506, 76, 'features_1_features_title', 'Вес мешка'),
(507, 76, '_features_1_features_title', 'field_product_extra_features_features_title'),
(508, 76, 'features_1_features_value', '15 кг'),
(509, 76, '_features_1_features_value', 'field_product_extra_features_features_value'),
(510, 76, 'product_price', '55₽ / кг'),
(511, 76, '_product_price', 'field_product_extra_product_price'),
(512, 76, 'product_button-text', 'Рассчитать количество Эковаты'),
(513, 76, '_product_button-text', 'field_product_extra_product_button-text'),
(514, 76, 'product_button_text', 'Рассчитать количество Эковаты'),
(515, 76, '_product_button_text', 'field_product_extra_product_button_text'),
(516, 77, '_wp_attached_file', '2022/08/product-size-icon-2.svg'),
(517, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:39;s:6:"height";i:47;s:4:"file";s:31:"2022/08/product-size-icon-2.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:23:"product-size-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9446;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:23:"product-size-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9446;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:23:"product-size-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9446;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:23:"product-size-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9446;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:23:"product-size-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9446;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:23:"product-size-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9446;}}s:8:"filesize";i:9446;}'),
(518, 78, '_wp_attached_file', '2022/08/product-weight-icon-2.svg'),
(519, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:45;s:6:"height";i:45;s:4:"file";s:33:"2022/08/product-weight-icon-2.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:25:"product-weight-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3103;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:25:"product-weight-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3103;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:25:"product-weight-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3103;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:25:"product-weight-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3103;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:25:"product-weight-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3103;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:25:"product-weight-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3103;}}s:8:"filesize";i:3103;}'),
(520, 79, 'features_0_features_icon', '77'),
(521, 79, '_features_0_features_icon', 'field_product_extra_features_features_icon') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(522, 79, 'features_0_features_title', 'Размер мешка '),
(523, 79, '_features_0_features_title', 'field_product_extra_features_features_title'),
(524, 79, 'features_0_features_value', '750х460х360 мм'),
(525, 79, '_features_0_features_value', 'field_product_extra_features_features_value'),
(526, 79, 'features_1_features_icon', '78'),
(527, 79, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(528, 79, 'features_1_features_title', 'Вес мешка 15 кг'),
(529, 79, '_features_1_features_title', 'field_product_extra_features_features_title'),
(530, 79, 'features_1_features_value', '15 кг'),
(531, 79, '_features_1_features_value', 'field_product_extra_features_features_value'),
(532, 79, 'features', '2'),
(533, 79, '_features', 'field_product_extra_features'),
(534, 79, 'product_price', '35₽ / кг'),
(535, 79, '_product_price', 'field_product_extra_product_price'),
(536, 79, 'product_button-text', 'Заказать Мульчу'),
(537, 79, '_product_button-text', 'field_product_extra_product_button-text'),
(538, 79, 'product_button_text', 'Заказать Мульчу'),
(539, 79, '_product_button_text', 'field_product_extra_product_button_text'),
(540, 80, 'features_0_features_icon', '50'),
(541, 80, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(542, 80, 'features_0_features_title', 'Ячейка сетки'),
(543, 80, '_features_0_features_title', 'field_product_extra_features_features_title'),
(544, 80, 'features_0_features_value', '15х25 мм'),
(545, 80, '_features_0_features_value', 'field_product_extra_features_features_value'),
(546, 80, 'features_1_features_icon', '51'),
(547, 80, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(548, 80, 'features_1_features_title', 'Размер рулона'),
(549, 80, '_features_1_features_title', 'field_product_extra_features_features_title'),
(550, 80, 'features_1_features_value', '20 м<sup>2</sup>'),
(551, 80, '_features_1_features_value', 'field_product_extra_features_features_value'),
(552, 80, 'features', '2'),
(553, 80, '_features', 'field_product_extra_features'),
(554, 80, 'product_price', '2 700₽ / рулон'),
(555, 80, '_product_price', 'field_product_extra_product_price'),
(556, 80, 'product_button_text', 'Заказать сетку'),
(557, 80, '_product_button_text', 'field_product_extra_product_button_text'),
(558, 81, '_wp_attached_file', '2022/08/product-grid-icon.svg'),
(559, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:46;s:6:"height";i:47;s:4:"file";s:29:"2022/08/product-grid-icon.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:21:"product-grid-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:553;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:21:"product-grid-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:553;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:21:"product-grid-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:553;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:21:"product-grid-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:553;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:21:"product-grid-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:553;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:21:"product-grid-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:553;}}s:8:"filesize";i:553;}'),
(560, 82, '_wp_attached_file', '2022/08/product-roll-icon.svg'),
(561, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:63;s:6:"height";i:47;s:4:"file";s:29:"2022/08/product-roll-icon.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:21:"product-roll-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:7668;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:21:"product-roll-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:7668;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:21:"product-roll-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:7668;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:21:"product-roll-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:7668;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:21:"product-roll-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:7668;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:21:"product-roll-icon.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:7668;}}s:8:"filesize";i:7668;}'),
(562, 83, 'features_0_features_icon', '81'),
(563, 83, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(564, 83, 'features_0_features_title', 'Ячейка сетки'),
(565, 83, '_features_0_features_title', 'field_product_extra_features_features_title'),
(566, 83, 'features_0_features_value', '15х25 мм'),
(567, 83, '_features_0_features_value', 'field_product_extra_features_features_value'),
(568, 83, 'features_1_features_icon', '82'),
(569, 83, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(570, 83, 'features_1_features_title', 'Размер рулона'),
(571, 83, '_features_1_features_title', 'field_product_extra_features_features_title'),
(572, 83, 'features_1_features_value', '20 м<sup>2</sup>'),
(573, 83, '_features_1_features_value', 'field_product_extra_features_features_value'),
(574, 83, 'features', '2'),
(575, 83, '_features', 'field_product_extra_features'),
(576, 83, 'product_price', '2 700₽ / рулон'),
(577, 83, '_product_price', 'field_product_extra_product_price'),
(578, 83, 'product_button_text', 'Заказать сетку'),
(579, 83, '_product_button_text', 'field_product_extra_product_button_text'),
(580, 84, 'features_0_features_icon', '81'),
(581, 84, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(582, 84, 'features_0_features_title', 'Ячейка сетки'),
(583, 84, '_features_0_features_title', 'field_product_extra_features_features_title'),
(584, 84, 'features_0_features_value', '15х25 мм'),
(585, 84, '_features_0_features_value', 'field_product_extra_features_features_value'),
(586, 84, 'features_1_features_icon', '82'),
(587, 84, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(588, 84, 'features_1_features_title', 'Размер рулона'),
(589, 84, '_features_1_features_title', 'field_product_extra_features_features_title'),
(590, 84, 'features_1_features_value', '20 м<sup>2</sup>'),
(591, 84, '_features_1_features_value', 'field_product_extra_features_features_value'),
(592, 84, 'features', '2'),
(593, 84, '_features', 'field_product_extra_features'),
(594, 84, 'product_price', '2 700₽ / рулон'),
(595, 84, '_product_price', 'field_product_extra_product_price'),
(596, 84, 'product_button_text', 'Заказать сетку'),
(597, 84, '_product_button_text', 'field_product_extra_product_button_text'),
(598, 85, '_wp_attached_file', '2022/08/product-size-icon-2-1.svg'),
(599, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:39;s:6:"height";i:47;s:4:"file";s:33:"2022/08/product-size-icon-2-1.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:25:"product-size-icon-2-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9007;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:25:"product-size-icon-2-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9007;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:25:"product-size-icon-2-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9007;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:25:"product-size-icon-2-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9007;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:25:"product-size-icon-2-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9007;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:25:"product-size-icon-2-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:9007;}}s:8:"filesize";i:9007;}'),
(600, 86, 'features_0_features_icon', '85'),
(601, 86, '_features_0_features_icon', 'field_product_extra_features_features_icon'),
(602, 86, 'features_0_features_title', 'Размер мешка '),
(603, 86, '_features_0_features_title', 'field_product_extra_features_features_title'),
(604, 86, 'features_0_features_value', '750х460х360 мм'),
(605, 86, '_features_0_features_value', 'field_product_extra_features_features_value'),
(606, 86, 'features_1_features_icon', '78'),
(607, 86, '_features_1_features_icon', 'field_product_extra_features_features_icon'),
(608, 86, 'features_1_features_title', 'Вес мешка 15 кг'),
(609, 86, '_features_1_features_title', 'field_product_extra_features_features_title'),
(610, 86, 'features_1_features_value', '15 кг'),
(611, 86, '_features_1_features_value', 'field_product_extra_features_features_value'),
(612, 86, 'features', '2'),
(613, 86, '_features', 'field_product_extra_features'),
(614, 86, 'product_price', '35₽ / кг'),
(615, 86, '_product_price', 'field_product_extra_product_price'),
(616, 86, 'product_button-text', 'Заказать Мульчу'),
(617, 86, '_product_button-text', 'field_product_extra_product_button-text'),
(618, 86, 'product_button_text', 'Заказать Мульчу'),
(619, 86, '_product_button_text', 'field_product_extra_product_button_text'),
(620, 93, '_wp_attached_file', '2022/08/advantages-image.png'),
(621, 93, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:777;s:6:"height";i:926;s:4:"file";s:28:"2022/08/advantages-image.png";s:8:"filesize";i:420002;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:28:"advantages-image-252x300.png";s:5:"width";i:252;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:73751;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"advantages-image-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28310;}s:12:"medium_large";a:5:{s:4:"file";s:28:"advantages-image-768x915.png";s:5:"width";i:768;s:6:"height";i:915;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:466202;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(622, 94, '_wp_attached_file', '2022/08/advantages-icon-1.svg'),
(623, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:146;s:6:"height";i:146;s:4:"file";s:29:"2022/08/advantages-icon-1.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:21:"advantages-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:2607;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:2607;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:2607;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:2607;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:2607;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-1.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:2607;}}s:8:"filesize";i:2607;}'),
(624, 95, '_wp_attached_file', '2022/08/advantages-icon-2.svg'),
(625, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:146;s:6:"height";i:146;s:4:"file";s:29:"2022/08/advantages-icon-2.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:21:"advantages-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:8925;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:8925;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:8925;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:8925;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:8925;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-2.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:8925;}}s:8:"filesize";i:8925;}'),
(626, 96, '_wp_attached_file', '2022/08/advantages-icon-3.svg'),
(627, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:146;s:6:"height";i:146;s:4:"file";s:29:"2022/08/advantages-icon-3.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:21:"advantages-icon-3.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3712;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-3.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3712;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-3.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3712;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-3.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3712;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-3.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3712;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-3.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3712;}}s:8:"filesize";i:3712;}'),
(628, 97, '_wp_attached_file', '2022/08/advantages-icon-4.svg'),
(629, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:146;s:6:"height";i:146;s:4:"file";s:29:"2022/08/advantages-icon-4.svg";s:5:"sizes";a:6:{s:9:"thumbnail";a:6:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";s:1:"1";s:4:"file";s:21:"advantages-icon-4.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3468;}s:6:"medium";a:6:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-4.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3468;}s:12:"medium_large";a:6:{s:5:"width";s:3:"768";s:6:"height";s:1:"0";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-4.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3468;}s:5:"large";a:6:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;s:4:"file";s:21:"advantages-icon-4.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3468;}s:9:"1536x1536";a:6:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-4.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3468;}s:9:"2048x2048";a:6:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";i:0;s:4:"file";s:21:"advantages-icon-4.svg";s:9:"mime-type";s:13:"image/svg+xml";s:8:"filesize";i:3468;}}s:8:"filesize";i:3468;}'),
(632, 101, '_wp_attached_file', '2022/08/certificate-image-1.png'),
(633, 101, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:544;s:6:"height";i:760;s:4:"file";s:31:"2022/08/certificate-image-1.png";s:8:"filesize";i:866554;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:31:"certificate-image-1-215x300.png";s:5:"width";i:215;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:137817;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"certificate-image-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:48062;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(634, 102, '_wp_attached_file', '2022/08/certificate-image-2.png'),
(635, 102, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:403;s:6:"height";i:560;s:4:"file";s:31:"2022/08/certificate-image-2.png";s:8:"filesize";i:431220;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:31:"certificate-image-2-216x300.png";s:5:"width";i:216;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:130528;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"certificate-image-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44074;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(636, 103, '_wp_attached_file', '2022/08/certificate-image-3.png'),
(637, 103, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:402;s:6:"height";i:560;s:4:"file";s:31:"2022/08/certificate-image-3.png";s:8:"filesize";i:130568;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:31:"certificate-image-3-215x300.png";s:5:"width";i:215;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52282;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"certificate-image-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23299;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(638, 104, '_wp_attached_file', '2022/08/certificate-image-4.png'),
(639, 104, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:544;s:6:"height";i:760;s:4:"file";s:31:"2022/08/certificate-image-4.png";s:8:"filesize";i:866554;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:31:"certificate-image-4-215x300.png";s:5:"width";i:215;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:137817;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"certificate-image-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:48062;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(640, 105, '_wp_attached_file', '2022/08/certificate-image-5.png'),
(641, 105, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:403;s:6:"height";i:560;s:4:"file";s:31:"2022/08/certificate-image-5.png";s:8:"filesize";i:431220;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:31:"certificate-image-5-216x300.png";s:5:"width";i:216;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:130528;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"certificate-image-5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44074;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(642, 106, '_wp_attached_file', '2022/08/certificate-image-6-e1659910572360.png'),
(643, 106, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:402;s:6:"height";i:560;s:4:"file";s:46:"2022/08/certificate-image-6-e1659910572360.png";s:8:"filesize";i:161281;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:46:"certificate-image-6-e1659910572360-215x300.png";s:5:"width";i:215;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52282;}s:9:"thumbnail";a:5:{s:4:"file";s:46:"certificate-image-6-e1659910572360-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23299;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(644, 106, '_edit_lock', '1659910393:1'),
(645, 106, '_wp_attachment_backup_sizes', 'a:6:{s:9:"full-orig";a:3:{s:5:"width";i:402;s:6:"height";i:560;s:4:"file";s:23:"certificate-image-6.png";}s:14:"thumbnail-orig";a:5:{s:4:"file";s:31:"certificate-image-6-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23299;}s:11:"medium-orig";a:5:{s:4:"file";s:31:"certificate-image-6-215x300.png";s:5:"width";i:215;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52282;}s:18:"full-1659910572360";a:3:{s:5:"width";i:402;s:6:"height";i:560;s:4:"file";s:38:"certificate-image-6-e1659910514609.png";}s:23:"thumbnail-1659910572360";a:5:{s:4:"file";s:46:"certificate-image-6-e1659910514609-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23299;}s:20:"medium-1659910572360";a:5:{s:4:"file";s:46:"certificate-image-6-e1659910514609-215x300.png";s:5:"width";i:215;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52282;}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-08-06 22:12:38', '2022-08-06 19:12:38', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2022-08-06 22:12:38', '2022-08-06 19:12:38', '', 0, 'http://vateko.loc/?p=1', 0, 'post', '', 1),
(2, 1, '2022-08-06 22:12:38', '2022-08-06 19:12:38', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/calc {"id":"block_62efaa5a354ab","name":"acf/calc","data":{"calc_title":"Рассчитать количество \\u003cspan\\u003eэковаты\\u003c/span\\u003e","_calc_title":"field_calc_calc_title","items":"","_items":"field_calc_items"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/advantages {"id":"block_62efb901c8ff8","name":"acf/advantages","data":{"advantages_title":"\\u003cspan\\u003eПреимущества\\u003c/span\\u003e эковаты “Ватэко”","_advantages_title":"field_advantages_advantages_title","advantages_icon":93,"_advantages_icon":"field_advantages_advantages_icon","list_0_list_icon":94,"_list_0_list_icon":"field_advantages_list_list_icon","list_0_list_title":"Воздухопроницаемость","_list_0_list_title":"field_advantages_list_list_title","list_0_list_text":"Не имеет запаха и не пылит. Не содержит \\r\\nлетучих химикатов, не вызывает аллергии.","_list_0_list_text":"field_advantages_list_list_text","list_1_list_icon":95,"_list_1_list_icon":"field_advantages_list_list_icon","list_1_list_title":"Экологичность","_list_1_list_title":"field_advantages_list_list_title","list_1_list_text":"Производится из переработанной макулатуры \\r\\nи имеет невысокую стоимость.","_list_1_list_text":"field_advantages_list_list_text","list_2_list_icon":96,"_list_2_list_icon":"field_advantages_list_list_icon","list_2_list_title":"Капиллярная активность","_list_2_list_title":"field_advantages_list_list_title","list_2_list_text":"Принимает фиксированную форму. \\r\\nОбеспечивает приятный микроклимат, \\r\\nпропуская воздух и не накапливая пара и влаги.","_list_2_list_text":"field_advantages_list_list_text","list_3_list_icon":97,"_list_3_list_icon":"field_advantages_list_list_icon","list_3_list_title":"Теплоемкость","_list_3_list_title":"field_advantages_list_list_title","list_3_list_text":"Обладает теплопроводностью не выше 0,04 \\r\\nединиц. Защищена антисептиками от пожаров, \\r\\nплесени, грызунов и насекомых.","_list_3_list_text":"field_advantages_list_list_text","list":4,"_list":"field_advantages_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/certificates {"id":"block_62efee762b0c4","name":"acf/certificates","data":{"certificates_title":"Сертификаты качества","_certificates_title":"field_certificates_certificates_title","certificates_slider_0_certificates_image":101,"_certificates_slider_0_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_0_certificates_item_title":"Сертификат соответствия","_certificates_slider_0_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_0_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_0_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_1_certificates_image":102,"_certificates_slider_1_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_1_certificates_item_title":"Сертификат соответствия","_certificates_slider_1_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_1_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_1_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_2_certificates_image":103,"_certificates_slider_2_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_2_certificates_item_title":"Сертификат соответствия","_certificates_slider_2_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_2_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_2_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_3_certificates_image":104,"_certificates_slider_3_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_3_certificates_item_title":"Сертификат соответствия","_certificates_slider_3_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_3_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_3_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_4_certificates_image":105,"_certificates_slider_4_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_4_certificates_item_title":"Сертификат соответствия","_certificates_slider_4_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_4_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_4_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_5_certificates_image":106,"_certificates_slider_5_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_5_certificates_item_title":"Сертификат соответствия","_certificates_slider_5_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_5_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_5_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider":6,"_certificates_slider":"field_certificates_certificates_slider"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/learnmore {"id":"block_62f03bfe7c4bd","name":"acf/learnmore","data":{"learnmore_title":"Узнать больше об Эковате","_learnmore_title":"field_learnmore_learnmore_title","learnmore_text":"Заполните форму и получите на почту бесплатную презентацию \\r\\nо продукции «Ватэко». Из презентации вы узнаете о составе, \\r\\nсвойствах и способах нанесения эковаты.","_learnmore_text":"field_learnmore_learnmore_text","learnmore_shortcode":"","_learnmore_shortcode":"field_learnmore_learnmore_shortcode"},"align":"","mode":"auto"} /-->', 'Главная', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2022-08-08 01:27:10', '2022-08-07 22:27:10', '', 0, 'http://vateko.loc/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-08-06 22:12:38', '2022-08-06 19:12:38', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://vateko.loc.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-08-06 22:12:38', '2022-08-06 19:12:38', '', 0, 'http://vateko.loc/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-08-06 22:13:39', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-06 22:13:39', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?p=4', 0, 'post', '', 0),
(5, 1, '2022-08-06 22:26:05', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-06 22:26:05', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=5', 0, 'product', '', 0),
(6, 1, '2022-08-06 22:26:06', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-06 22:26:06', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=6', 0, 'product', '', 0),
(7, 1, '2022-08-06 22:38:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-06 22:38:41', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=7', 0, 'product', '', 0),
(8, 1, '2022-08-06 22:40:27', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-06 22:40:27', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=8', 0, 'product', '', 0),
(9, 1, '2022-08-06 22:43:31', '2022-08-06 19:43:31', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-06 22:43:31', '2022-08-06 19:43:31', '', 2, 'http://vateko.loc/?p=9', 0, 'revision', '', 0),
(12, 1, '2022-08-06 22:53:34', '2022-08-06 19:53:34', '', 'bigbuckbunny', '', 'inherit', 'open', 'closed', '', 'bigbuckbunny', '', '', '2022-08-06 22:53:34', '2022-08-06 19:53:34', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/bigbuckbunny-1.mp4', 0, 'attachment', 'video/mp4', 0),
(13, 1, '2022-08-06 22:53:59', '2022-08-06 19:53:59', '', 'hero-img', '', 'inherit', 'open', 'closed', '', 'hero-img', '', '', '2022-08-06 22:53:59', '2022-08-06 19:53:59', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/hero-img-1.png', 0, 'attachment', 'image/png', 0),
(14, 1, '2022-08-06 22:59:12', '2022-08-06 19:59:12', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-06 22:59:12', '2022-08-06 19:59:12', '', 2, 'http://vateko.loc/?p=14', 0, 'revision', '', 0),
(15, 1, '2022-08-06 23:00:40', '2022-08-06 20:00:40', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":"","_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-06 23:00:40', '2022-08-06 20:00:40', '', 2, 'http://vateko.loc/?p=15', 0, 'revision', '', 0),
(16, 1, '2022-08-06 23:00:50', '2022-08-06 20:00:50', '', 'about-img', '', 'inherit', 'open', 'closed', '', 'about-img', '', '', '2022-08-06 23:00:50', '2022-08-06 20:00:50', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/about-img-1.png', 0, 'attachment', 'image/png', 0),
(17, 1, '2022-08-06 23:01:04', '2022-08-06 20:01:04', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-06 23:01:04', '2022-08-06 20:01:04', '', 2, 'http://vateko.loc/?p=17', 0, 'revision', '', 0),
(18, 1, '2022-08-06 23:01:27', '2022-08-06 20:01:27', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2022-08-06 23:01:27', '2022-08-06 20:01:27', '', 0, 'http://vateko.loc/wp-content/uploads/2022/08/logo-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(19, 1, '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 'Что такое ВатЭКО?', '', 'publish', 'closed', 'closed', '', 'chto-takoe-vateko', '', '', '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 0, 'http://vateko.loc/?p=19', 1, 'nav_menu_item', '', 0),
(20, 1, '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 'Наша продукция', '', 'publish', 'closed', 'closed', '', 'nasha-produkcziya', '', '', '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 0, 'http://vateko.loc/?p=20', 2, 'nav_menu_item', '', 0),
(21, 1, '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 'Преимущества', '', 'publish', 'closed', 'closed', '', 'preimushhestva', '', '', '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 0, 'http://vateko.loc/?p=21', 3, 'nav_menu_item', '', 0),
(22, 1, '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 'Стать партнером', '', 'publish', 'closed', 'closed', '', 'stat-partnerom', '', '', '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 0, 'http://vateko.loc/?p=22', 4, 'nav_menu_item', '', 0),
(23, 1, '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 'Контакты', '', 'publish', 'closed', 'closed', '', 'kontakty', '', '', '2022-08-06 23:05:15', '2022-08-06 20:05:15', '', 0, 'http://vateko.loc/?p=23', 5, 'nav_menu_item', '', 0),
(24, 1, '2022-08-06 23:42:26', '2022-08-06 20:42:26', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-06 23:42:26', '2022-08-06 20:42:26', '', 2, 'http://vateko.loc/?p=24', 0, 'revision', '', 0),
(25, 1, '2022-08-06 23:45:06', '2022-08-06 20:45:06', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-vateko10', '', '', '2022-08-06 23:45:06', '2022-08-06 20:45:06', '', 0, 'http://vateko.loc/?p=25', 0, 'wp_global_styles', '', 0),
(26, 1, '2022-08-06 23:45:09', '2022-08-06 20:45:09', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-06 23:45:09', '2022-08-06 20:45:09', '', 2, 'http://vateko.loc/?p=26', 0, 'revision', '', 0),
(28, 1, '2022-08-07 00:04:20', '2022-08-06 21:04:20', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-07 00:04:20', '2022-08-06 21:04:20', '', 2, 'http://vateko.loc/?p=28', 0, 'revision', '', 0),
(29, 1, '2022-08-07 00:11:45', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:11:45', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=29', 0, 'product', '', 0),
(30, 1, '2022-08-07 00:11:57', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:11:57', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=30', 0, 'product', '', 0),
(31, 1, '2022-08-07 00:13:46', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:13:46', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=31', 0, 'product', '', 0),
(32, 1, '2022-08-07 00:13:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:13:52', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=32', 0, 'product', '', 0),
(33, 1, '2022-08-07 00:14:13', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:14:13', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=33', 0, 'product', '', 0),
(34, 1, '2022-08-07 00:14:20', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:14:20', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=34', 0, 'product', '', 0),
(35, 1, '2022-08-07 00:15:55', '2022-08-06 21:15:55', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'publish', 'open', 'open', '', 'ekovata', '', '', '2022-08-07 13:11:29', '2022-08-07 10:11:29', '', 0, 'http://vateko.loc/?post_type=product&#038;p=35', 0, 'product', '', 0),
(36, 1, '2022-08-07 00:15:33', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:15:33', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=36', 0, 'product', '', 0),
(37, 1, '2022-08-07 00:15:55', '2022-08-06 21:15:55', '', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:15:55', '2022-08-06 21:15:55', '', 35, 'http://vateko.loc/?p=37', 0, 'revision', '', 0),
(41, 1, '2022-08-07 00:31:14', '2022-08-06 21:31:14', '', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:31:14', '2022-08-06 21:31:14', '', 35, 'http://vateko.loc/?p=41', 0, 'revision', '', 0),
(42, 1, '2022-08-07 00:33:22', '2022-08-06 21:33:22', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'publish', 'open', 'open', '', 'mulcha', '', '', '2022-08-07 13:19:51', '2022-08-07 10:19:51', '', 0, 'http://vateko.loc/?post_type=product&#038;p=42', 0, 'product', '', 0),
(43, 1, '2022-08-07 00:32:12', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:32:12', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=43', 0, 'product', '', 0),
(44, 1, '2022-08-07 00:33:22', '2022-08-06 21:33:22', '', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 00:33:22', '2022-08-06 21:33:22', '', 42, 'http://vateko.loc/?p=44', 0, 'revision', '', 0),
(45, 1, '2022-08-07 00:39:16', '2022-08-06 21:39:16', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'publish', 'open', 'open', '', 'plastikovaya-setka-dlya-montazha-ekovaty', '', '', '2022-08-07 13:19:32', '2022-08-07 10:19:32', '', 0, 'http://vateko.loc/?post_type=product&#038;p=45', 0, 'product', '', 0),
(46, 1, '2022-08-07 00:36:30', '2022-08-06 21:36:30', '', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 00:36:30', '2022-08-06 21:36:30', '', 42, 'http://vateko.loc/?p=46', 0, 'revision', '', 0),
(48, 1, '2022-08-07 00:36:32', '2022-08-06 21:36:32', '', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:36:32', '2022-08-06 21:36:32', '', 35, 'http://vateko.loc/?p=48', 0, 'revision', '', 0),
(49, 1, '2022-08-07 00:36:51', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-08-07 00:36:51', '0000-00-00 00:00:00', '', 0, 'http://vateko.loc/?post_type=product&p=49', 0, 'product', '', 0),
(52, 1, '2022-08-07 00:39:16', '2022-08-06 21:39:16', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 00:39:16', '2022-08-06 21:39:16', '', 45, 'http://vateko.loc/?p=52', 0, 'revision', '', 0),
(53, 1, '2022-08-07 00:39:19', '2022-08-06 21:39:19', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 00:39:19', '2022-08-06 21:39:19', '', 45, 'http://vateko.loc/?p=53', 0, 'revision', '', 0),
(54, 1, '2022-08-07 00:40:20', '2022-08-06 21:40:20', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:40:20', '2022-08-06 21:40:20', '', 35, 'http://vateko.loc/?p=54', 0, 'revision', '', 0),
(55, 1, '2022-08-07 00:40:25', '2022-08-06 21:40:25', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 00:40:25', '2022-08-06 21:40:25', '', 42, 'http://vateko.loc/?p=55', 0, 'revision', '', 0),
(56, 1, '2022-08-07 00:42:32', '2022-08-06 21:42:32', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:42:32', '2022-08-06 21:42:32', '', 35, 'http://vateko.loc/?p=56', 0, 'revision', '', 0),
(57, 1, '2022-08-07 00:43:10', '2022-08-06 21:43:10', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 00:43:10', '2022-08-06 21:43:10', '', 42, 'http://vateko.loc/?p=57', 0, 'revision', '', 0),
(58, 1, '2022-08-07 00:43:40', '2022-08-06 21:43:40', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 00:43:40', '2022-08-06 21:43:40', '', 45, 'http://vateko.loc/?p=58', 0, 'revision', '', 0),
(59, 1, '2022-08-07 00:43:48', '2022-08-06 21:43:48', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:43:48', '2022-08-06 21:43:48', '', 35, 'http://vateko.loc/?p=59', 0, 'revision', '', 0),
(60, 1, '2022-08-07 00:45:55', '2022-08-06 21:45:55', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 00:45:55', '2022-08-06 21:45:55', '', 35, 'http://vateko.loc/?p=60', 0, 'revision', '', 0),
(61, 1, '2022-08-07 00:46:31', '2022-08-06 21:46:31', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 00:46:31', '2022-08-06 21:46:31', '', 42, 'http://vateko.loc/?p=61', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(62, 1, '2022-08-07 12:29:54', '2022-08-07 09:29:54', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 12:29:54', '2022-08-07 09:29:54', '', 35, 'http://vateko.loc/?p=62', 0, 'revision', '', 0),
(63, 1, '2022-08-07 12:30:35', '2022-08-07 09:30:35', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 12:30:35', '2022-08-07 09:30:35', '', 42, 'http://vateko.loc/?p=63', 0, 'revision', '', 0),
(64, 1, '2022-08-07 12:30:56', '2022-08-07 09:30:56', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 12:30:56', '2022-08-07 09:30:56', '', 45, 'http://vateko.loc/?p=64', 0, 'revision', '', 0),
(65, 1, '2022-08-07 12:51:34', '2022-08-07 09:51:34', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 12:51:34', '2022-08-07 09:51:34', '', 45, 'http://vateko.loc/?p=65', 0, 'revision', '', 0),
(66, 1, '2022-08-07 12:52:59', '2022-08-07 09:52:59', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 12:52:59', '2022-08-07 09:52:59', '', 45, 'http://vateko.loc/?p=66', 0, 'revision', '', 0),
(69, 1, '2022-08-07 13:03:21', '2022-08-07 10:03:21', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 13:03:21', '2022-08-07 10:03:21', '', 35, 'http://vateko.loc/?p=69', 0, 'revision', '', 0),
(71, 1, '2022-08-07 13:04:23', '2022-08-07 10:04:23', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 13:04:23', '2022-08-07 10:04:23', '', 35, 'http://vateko.loc/?p=71', 0, 'revision', '', 0),
(73, 1, '2022-08-07 13:05:51', '2022-08-07 10:05:51', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 13:05:51', '2022-08-07 10:05:51', '', 35, 'http://vateko.loc/?p=73', 0, 'revision', '', 0),
(74, 1, '2022-08-07 13:10:57', '2022-08-07 10:10:57', '', 'product-size-icon-1', '', 'inherit', 'open', 'closed', '', 'product-size-icon-1', '', '', '2022-08-07 13:10:57', '2022-08-07 10:10:57', '', 35, 'http://vateko.loc/wp-content/uploads/2022/08/product-size-icon-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(75, 1, '2022-08-07 13:11:13', '2022-08-07 10:11:13', '', 'product-weight-icon-1', '', 'inherit', 'open', 'closed', '', 'product-weight-icon-1', '', '', '2022-08-07 13:11:13', '2022-08-07 10:11:13', '', 35, 'http://vateko.loc/wp-content/uploads/2022/08/product-weight-icon-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(76, 1, '2022-08-07 13:11:29', '2022-08-07 10:11:29', '<!-- wp:paragraph -->\n<p>Эковата “Ватэко” - Натуральный целлюлозный,<br>не поддерживающий горение утеплитель.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется для утепления и звукоизоляции стен, крыш, перекрытий и перегородок в жилом и промышленном строительстве.</p>\n<!-- /wp:paragraph -->', 'Эковата', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2022-08-07 13:11:29', '2022-08-07 10:11:29', '', 35, 'http://vateko.loc/?p=76', 0, 'revision', '', 0),
(77, 1, '2022-08-07 13:13:03', '2022-08-07 10:13:03', '', 'product-size-icon-2', '', 'inherit', 'open', 'closed', '', 'product-size-icon-2', '', '', '2022-08-07 13:13:03', '2022-08-07 10:13:03', '', 42, 'http://vateko.loc/wp-content/uploads/2022/08/product-size-icon-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(78, 1, '2022-08-07 13:13:17', '2022-08-07 10:13:17', '', 'product-weight-icon-2', '', 'inherit', 'open', 'closed', '', 'product-weight-icon-2', '', '', '2022-08-07 13:13:17', '2022-08-07 10:13:17', '', 42, 'http://vateko.loc/wp-content/uploads/2022/08/product-weight-icon-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(79, 1, '2022-08-07 13:13:37', '2022-08-07 10:13:37', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 13:13:37', '2022-08-07 10:13:37', '', 42, 'http://vateko.loc/?p=79', 0, 'revision', '', 0),
(80, 1, '2022-08-07 13:13:50', '2022-08-07 10:13:50', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 13:13:50', '2022-08-07 10:13:50', '', 45, 'http://vateko.loc/?p=80', 0, 'revision', '', 0),
(81, 1, '2022-08-07 13:17:28', '2022-08-07 10:17:28', '', 'product-grid-icon', '', 'inherit', 'open', 'closed', '', 'product-grid-icon', '', '', '2022-08-07 13:17:28', '2022-08-07 10:17:28', '', 45, 'http://vateko.loc/wp-content/uploads/2022/08/product-grid-icon.svg', 0, 'attachment', 'image/svg+xml', 0),
(82, 1, '2022-08-07 13:17:41', '2022-08-07 10:17:41', '', 'product-roll-icon', '', 'inherit', 'open', 'closed', '', 'product-roll-icon', '', '', '2022-08-07 13:17:41', '2022-08-07 10:17:41', '', 45, 'http://vateko.loc/wp-content/uploads/2022/08/product-roll-icon.svg', 0, 'attachment', 'image/svg+xml', 0),
(83, 1, '2022-08-07 13:17:56', '2022-08-07 10:17:56', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 13:17:56', '2022-08-07 10:17:56', '', 45, 'http://vateko.loc/?p=83', 0, 'revision', '', 0),
(84, 1, '2022-08-07 13:19:32', '2022-08-07 10:19:32', '<!-- wp:paragraph -->\n<p>Пластиковая сетка “Теплокаркас” - полимерная армирующая сетка,<br>которая применяется для качественного монтажа эковаты<br>на вертикальные и горизонтальные конструкции.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Используется для утепления фасадов, стен, потолков,<br>внутренних перегородок и кровель всех типов.</p>\n<!-- /wp:paragraph -->', 'Пластиковая сетка для монтажа Эковаты', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2022-08-07 13:19:32', '2022-08-07 10:19:32', '', 45, 'http://vateko.loc/?p=84', 0, 'revision', '', 0),
(85, 1, '2022-08-07 13:19:37', '2022-08-07 10:19:37', '', 'product-size-icon-2', '', 'inherit', 'open', 'closed', '', 'product-size-icon-2-2', '', '', '2022-08-07 13:19:37', '2022-08-07 10:19:37', '', 42, 'http://vateko.loc/wp-content/uploads/2022/08/product-size-icon-2-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(86, 1, '2022-08-07 13:19:51', '2022-08-07 10:19:51', '<!-- wp:paragraph -->\n<p>Мульча “ВАТЭКО” - Натуральный, технический и целлюлозный материал (без минеральных добавок).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Применяется в гидропосеве газонов и обочин дорог, мульчировании почвы на огородах и в теплицах.</p>\n<!-- /wp:paragraph -->', 'Мульча', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2022-08-07 13:19:51', '2022-08-07 10:19:51', '', 42, 'http://vateko.loc/?p=86', 0, 'revision', '', 0),
(88, 1, '2022-08-07 14:22:47', '2022-08-07 11:22:47', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-07 14:22:47', '2022-08-07 11:22:47', '', 2, 'http://vateko.loc/?p=88', 0, 'revision', '', 0),
(90, 1, '2022-08-07 14:25:43', '2022-08-07 11:25:43', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-07 14:25:43', '2022-08-07 11:25:43', '', 2, 'http://vateko.loc/?p=90', 0, 'revision', '', 0),
(91, 1, '2022-08-07 15:05:22', '2022-08-07 12:05:22', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/calc {"id":"block_62efaa5a354ab","name":"acf/calc","data":{"calc_title":"Рассчитать количество \\u003cspan\\u003eэковаты\\u003c/span\\u003e","_calc_title":"field_calc_calc_title","items":"","_items":"field_calc_items"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-07 15:05:22', '2022-08-07 12:05:22', '', 2, 'http://vateko.loc/?p=91', 0, 'revision', '', 0),
(93, 1, '2022-08-07 16:09:05', '2022-08-07 13:09:05', '', 'advantages-image', '', 'inherit', 'open', 'closed', '', 'advantages-image', '', '', '2022-08-07 16:09:05', '2022-08-07 13:09:05', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/advantages-image.png', 0, 'attachment', 'image/png', 0),
(94, 1, '2022-08-07 16:09:37', '2022-08-07 13:09:37', '', 'advantages-icon-1', '', 'inherit', 'open', 'closed', '', 'advantages-icon-1', '', '', '2022-08-07 16:09:37', '2022-08-07 13:09:37', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/advantages-icon-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(95, 1, '2022-08-07 16:09:50', '2022-08-07 13:09:50', '', 'advantages-icon-2', '', 'inherit', 'open', 'closed', '', 'advantages-icon-2', '', '', '2022-08-07 16:09:50', '2022-08-07 13:09:50', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/advantages-icon-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(96, 1, '2022-08-07 16:10:02', '2022-08-07 13:10:02', '', 'advantages-icon-3', '', 'inherit', 'open', 'closed', '', 'advantages-icon-3', '', '', '2022-08-07 16:10:02', '2022-08-07 13:10:02', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/advantages-icon-3.svg', 0, 'attachment', 'image/svg+xml', 0),
(97, 1, '2022-08-07 16:10:13', '2022-08-07 13:10:13', '', 'advantages-icon-4', '', 'inherit', 'open', 'closed', '', 'advantages-icon-4', '', '', '2022-08-07 16:10:13', '2022-08-07 13:10:13', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/advantages-icon-4.svg', 0, 'attachment', 'image/svg+xml', 0),
(98, 1, '2022-08-07 16:11:50', '2022-08-07 13:11:50', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/calc {"id":"block_62efaa5a354ab","name":"acf/calc","data":{"calc_title":"Рассчитать количество \\u003cspan\\u003eэковаты\\u003c/span\\u003e","_calc_title":"field_calc_calc_title","items":"","_items":"field_calc_items"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/advantages {"id":"block_62efb901c8ff8","name":"acf/advantages","data":{"advantages_title":"\\u003cspan\\u003eПреимущества\\u003c/span\\u003e эковаты “Ватэко”","_advantages_title":"field_advantages_advantages_title","advantages_icon":93,"_advantages_icon":"field_advantages_advantages_icon","list_0_list_icon":94,"_list_0_list_icon":"field_advantages_list_list_icon","list_0_list_title":"Воздухопроницаемость","_list_0_list_title":"field_advantages_list_list_title","list_0_list_text":"Не имеет запаха и не пылит. Не содержит \\r\\nлетучих химикатов, не вызывает аллергии.","_list_0_list_text":"field_advantages_list_list_text","list_1_list_icon":95,"_list_1_list_icon":"field_advantages_list_list_icon","list_1_list_title":"Экологичность","_list_1_list_title":"field_advantages_list_list_title","list_1_list_text":"Производится из переработанной макулатуры \\r\\nи имеет невысокую стоимость.","_list_1_list_text":"field_advantages_list_list_text","list_2_list_icon":96,"_list_2_list_icon":"field_advantages_list_list_icon","list_2_list_title":"Капиллярная активность","_list_2_list_title":"field_advantages_list_list_title","list_2_list_text":"Принимает фиксированную форму. \\r\\nОбеспечивает приятный микроклимат, \\r\\nпропуская воздух и не накапливая пара и влаги.","_list_2_list_text":"field_advantages_list_list_text","list_3_list_icon":97,"_list_3_list_icon":"field_advantages_list_list_icon","list_3_list_title":"Теплоемкость","_list_3_list_title":"field_advantages_list_list_title","list_3_list_text":"Обладает теплопроводностью не выше 0,04 \\r\\nединиц. Защищена антисептиками от пожаров, \\r\\nплесени, грызунов и насекомых.","_list_3_list_text":"field_advantages_list_list_text","list":4,"_list":"field_advantages_list"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-07 16:11:50', '2022-08-07 13:11:50', '', 2, 'http://vateko.loc/?p=98', 0, 'revision', '', 0),
(100, 1, '2022-08-08 01:28:02', '2022-08-07 22:28:02', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/calc {"id":"block_62efaa5a354ab","name":"acf/calc","data":{"calc_title":"Рассчитать количество \\u003cspan\\u003eэковаты\\u003c/span\\u003e","_calc_title":"field_calc_calc_title","items":"","_items":"field_calc_items"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/advantages {"id":"block_62efb901c8ff8","name":"acf/advantages","data":{"advantages_title":"\\u003cspan\\u003eПреимущества\\u003c/span\\u003e эковаты “Ватэко”","_advantages_title":"field_advantages_advantages_title","advantages_icon":93,"_advantages_icon":"field_advantages_advantages_icon","list_0_list_icon":94,"_list_0_list_icon":"field_advantages_list_list_icon","list_0_list_title":"Воздухопроницаемость","_list_0_list_title":"field_advantages_list_list_title","list_0_list_text":"Не имеет запаха и не пылит. Не содержит \\r\\nлетучих химикатов, не вызывает аллергии.","_list_0_list_text":"field_advantages_list_list_text","list_1_list_icon":95,"_list_1_list_icon":"field_advantages_list_list_icon","list_1_list_title":"Экологичность","_list_1_list_title":"field_advantages_list_list_title","list_1_list_text":"Производится из переработанной макулатуры \\r\\nи имеет невысокую стоимость.","_list_1_list_text":"field_advantages_list_list_text","list_2_list_icon":96,"_list_2_list_icon":"field_advantages_list_list_icon","list_2_list_title":"Капиллярная активность","_list_2_list_title":"field_advantages_list_list_title","list_2_list_text":"Принимает фиксированную форму. \\r\\nОбеспечивает приятный микроклимат, \\r\\nпропуская воздух и не накапливая пара и влаги.","_list_2_list_text":"field_advantages_list_list_text","list_3_list_icon":97,"_list_3_list_icon":"field_advantages_list_list_icon","list_3_list_title":"Теплоемкость","_list_3_list_title":"field_advantages_list_list_title","list_3_list_text":"Обладает теплопроводностью не выше 0,04 \\r\\nединиц. Защищена антисептиками от пожаров, \\r\\nплесени, грызунов и насекомых.","_list_3_list_text":"field_advantages_list_list_text","list":4,"_list":"field_advantages_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/certificates {"id":"block_62efee762b0c4","name":"acf/certificates","data":{"certificates_title":"Сертификаты качества","_certificates_title":"field_certificates_certificates_title","certificates_slider_0_certificates_image":101,"_certificates_slider_0_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_0_certificates_item_title":"Сертификат соответствия","_certificates_slider_0_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_0_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_0_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_1_certificates_image":102,"_certificates_slider_1_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_1_certificates_item_title":"Сертификат соответствия","_certificates_slider_1_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_1_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_1_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_2_certificates_image":103,"_certificates_slider_2_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_2_certificates_item_title":"Сертификат соответствия","_certificates_slider_2_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_2_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_2_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_3_certificates_image":104,"_certificates_slider_3_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_3_certificates_item_title":"Сертификат соответствия","_certificates_slider_3_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_3_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_3_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_4_certificates_image":105,"_certificates_slider_4_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_4_certificates_item_title":"Сертификат соответствия","_certificates_slider_4_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_4_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_4_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_5_certificates_image":106,"_certificates_slider_5_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_5_certificates_item_title":"Сертификат соответствия","_certificates_slider_5_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_5_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_5_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider":6,"_certificates_slider":"field_certificates_certificates_slider"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/learnmore {"id":"block_62f03bfe7c4bd","name":"acf/learnmore","data":{"learnmore_title":"Узнать больше об Эковате","_learnmore_title":"field_learnmore_learnmore_title","learnmore_text":"Заполните форму и получите на почту бесплатную презентацию \\r\\nо продукции «Ватэко». Из презентации вы узнаете о составе, \\r\\nсвойствах и способах нанесения эковаты.","_learnmore_text":"field_learnmore_learnmore_text","learnmore_shortcode":"","_learnmore_shortcode":"field_learnmore_learnmore_shortcode"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-autosave-v1', '', '', '2022-08-08 01:28:02', '2022-08-07 22:28:02', '', 2, 'http://vateko.loc/?p=100', 0, 'revision', '', 0),
(101, 1, '2022-08-07 19:57:10', '2022-08-07 16:57:10', '', 'certificate-image-1', '', 'inherit', 'open', 'closed', '', 'certificate-image-1', '', '', '2022-08-07 19:57:10', '2022-08-07 16:57:10', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/certificate-image-1.png', 0, 'attachment', 'image/png', 0),
(102, 1, '2022-08-07 19:57:53', '2022-08-07 16:57:53', '', 'certificate-image-2', '', 'inherit', 'open', 'closed', '', 'certificate-image-2', '', '', '2022-08-07 19:57:53', '2022-08-07 16:57:53', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/certificate-image-2.png', 0, 'attachment', 'image/png', 0),
(103, 1, '2022-08-07 19:58:06', '2022-08-07 16:58:06', '', 'certificate-image-3', '', 'inherit', 'open', 'closed', '', 'certificate-image-3', '', '', '2022-08-07 19:58:06', '2022-08-07 16:58:06', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/certificate-image-3.png', 0, 'attachment', 'image/png', 0),
(104, 1, '2022-08-07 19:58:20', '2022-08-07 16:58:20', '', 'certificate-image-4', '', 'inherit', 'open', 'closed', '', 'certificate-image-4', '', '', '2022-08-07 19:58:20', '2022-08-07 16:58:20', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/certificate-image-4.png', 0, 'attachment', 'image/png', 0),
(105, 1, '2022-08-07 19:58:42', '2022-08-07 16:58:42', '', 'certificate-image-5', '', 'inherit', 'open', 'closed', '', 'certificate-image-5', '', '', '2022-08-07 19:58:42', '2022-08-07 16:58:42', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/certificate-image-5.png', 0, 'attachment', 'image/png', 0),
(106, 1, '2022-08-07 19:58:57', '2022-08-07 16:58:57', '', 'certificate-image-6', '', 'inherit', 'open', 'closed', '', 'certificate-image-6', '', '', '2022-08-07 19:58:57', '2022-08-07 16:58:57', '', 2, 'http://vateko.loc/wp-content/uploads/2022/08/certificate-image-6.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(107, 1, '2022-08-07 19:59:09', '2022-08-07 16:59:09', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/calc {"id":"block_62efaa5a354ab","name":"acf/calc","data":{"calc_title":"Рассчитать количество \\u003cspan\\u003eэковаты\\u003c/span\\u003e","_calc_title":"field_calc_calc_title","items":"","_items":"field_calc_items"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/advantages {"id":"block_62efb901c8ff8","name":"acf/advantages","data":{"advantages_title":"\\u003cspan\\u003eПреимущества\\u003c/span\\u003e эковаты “Ватэко”","_advantages_title":"field_advantages_advantages_title","advantages_icon":93,"_advantages_icon":"field_advantages_advantages_icon","list_0_list_icon":94,"_list_0_list_icon":"field_advantages_list_list_icon","list_0_list_title":"Воздухопроницаемость","_list_0_list_title":"field_advantages_list_list_title","list_0_list_text":"Не имеет запаха и не пылит. Не содержит \\r\\nлетучих химикатов, не вызывает аллергии.","_list_0_list_text":"field_advantages_list_list_text","list_1_list_icon":95,"_list_1_list_icon":"field_advantages_list_list_icon","list_1_list_title":"Экологичность","_list_1_list_title":"field_advantages_list_list_title","list_1_list_text":"Производится из переработанной макулатуры \\r\\nи имеет невысокую стоимость.","_list_1_list_text":"field_advantages_list_list_text","list_2_list_icon":96,"_list_2_list_icon":"field_advantages_list_list_icon","list_2_list_title":"Капиллярная активность","_list_2_list_title":"field_advantages_list_list_title","list_2_list_text":"Принимает фиксированную форму. \\r\\nОбеспечивает приятный микроклимат, \\r\\nпропуская воздух и не накапливая пара и влаги.","_list_2_list_text":"field_advantages_list_list_text","list_3_list_icon":97,"_list_3_list_icon":"field_advantages_list_list_icon","list_3_list_title":"Теплоемкость","_list_3_list_title":"field_advantages_list_list_title","list_3_list_text":"Обладает теплопроводностью не выше 0,04 \\r\\nединиц. Защищена антисептиками от пожаров, \\r\\nплесени, грызунов и насекомых.","_list_3_list_text":"field_advantages_list_list_text","list":4,"_list":"field_advantages_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/certificates {"id":"block_62efee762b0c4","name":"acf/certificates","data":{"certificates_title":"Сертификаты качества","_certificates_title":"field_certificates_certificates_title","certificates_slider_0_certificates_image":101,"_certificates_slider_0_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_0_certificates_item_title":"Сертификат соответствия","_certificates_slider_0_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_0_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_0_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_1_certificates_image":102,"_certificates_slider_1_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_1_certificates_item_title":"Сертификат соответствия","_certificates_slider_1_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_1_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_1_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_2_certificates_image":103,"_certificates_slider_2_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_2_certificates_item_title":"Сертификат соответствия","_certificates_slider_2_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_2_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_2_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_3_certificates_image":104,"_certificates_slider_3_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_3_certificates_item_title":"Сертификат соответствия","_certificates_slider_3_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_3_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_3_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_4_certificates_image":105,"_certificates_slider_4_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_4_certificates_item_title":"Сертификат соответствия","_certificates_slider_4_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_4_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_4_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_5_certificates_image":106,"_certificates_slider_5_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_5_certificates_item_title":"Сертификат соответствия","_certificates_slider_5_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_5_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_5_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider":6,"_certificates_slider":"field_certificates_certificates_slider"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-07 19:59:09', '2022-08-07 16:59:09', '', 2, 'http://vateko.loc/?p=107', 0, 'revision', '', 0),
(108, 1, '2022-08-08 01:27:10', '2022-08-07 22:27:10', '<!-- wp:acf/hero {"id":"block_62eec4467b0c9","name":"acf/hero","data":{"hero_title":"Эковата «ВАТЭКО» — \\u003cspan\\u003eбезопасный утеплитель\\u003c/span\\u003e","_hero_title":"field_hero_hero_title","hero_image":13,"_hero_image":"field_hero_hero_image","hero_file":12,"_hero_file":"field_hero_hero_file","hero_text":"Экологичный строительный материал, простой \\r\\nв работе и обладающий уникальными тепло- \\r\\nи звукоизоляционными свойствами","_hero_text":"field_hero_hero_text","hero_url":"","_hero_url":"field_hero_hero_url"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/about {"id":"block_62eec44b7b0cc","name":"acf/about","data":{"about_title":"Что такое эковата \\u003cspan\\u003e«Ватэко»?\\u003c/span\\u003e","_about_title":"field_about_about_title","about_subtitle":"Это лёгкий волокнистый материал \\r\\nсерого цвета. ","_about_subtitle":"field_about_about_subtitle","about_text":"Эковата на 82% состоит из переработанной бумаги и на 18% —\\r\\nиз природных антисептиков и огнезащитных компонентов,\\r\\nчто делает её безопасной для людей и окружающей среды.\\r\\n\\r\\nВату используют для бесшовного утепления домов,\\r\\nмансард, ангаров и других сооружений.","_about_text":"field_about_about_text","about_image":16,"_about_image":"field_about_about_image"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/products {"id":"block_62eec44d7b0cd","name":"acf/products","data":{"products_title":"Наша продукция","_products_title":"field_products_products_title"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/stats {"id":"block_62efa007ecdfa","name":"acf/stats","data":{"stats_title":"Ватэко в цифрах","_stats_title":"field_stats_stats_title","stats_list_0_stats_item_title":"25 лет","_stats_list_0_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_0_stats_item_text":"материал сохраняет \\u003cstrong\\u003eтепло- \\r\\nи звукоизоляционные\\u003c/strong\\u003e свойства","_stats_list_0_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_1_stats_item_title":"65 ДБ","_stats_list_1_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_1_stats_item_text":"степень \\u003cstrong\\u003eзвукоизоляции\\u003c/strong\\u003e стены, \\r\\nутеплённой эковатой","_stats_list_1_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list_2_stats_item_title":"На 25%","_stats_list_2_stats_item_title":"field_stats_stats_list_stats_item_title","stats_list_2_stats_item_text":"\\u003cstrong\\u003eснижает затраты\\u003c/strong\\u003e на обогрев\\r\\nпомещения","_stats_list_2_stats_item_text":"field_stats_stats_list_stats_item_text","stats_list":3,"_stats_list":"field_stats_stats_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/calc {"id":"block_62efaa5a354ab","name":"acf/calc","data":{"calc_title":"Рассчитать количество \\u003cspan\\u003eэковаты\\u003c/span\\u003e","_calc_title":"field_calc_calc_title","items":"","_items":"field_calc_items"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/advantages {"id":"block_62efb901c8ff8","name":"acf/advantages","data":{"advantages_title":"\\u003cspan\\u003eПреимущества\\u003c/span\\u003e эковаты “Ватэко”","_advantages_title":"field_advantages_advantages_title","advantages_icon":93,"_advantages_icon":"field_advantages_advantages_icon","list_0_list_icon":94,"_list_0_list_icon":"field_advantages_list_list_icon","list_0_list_title":"Воздухопроницаемость","_list_0_list_title":"field_advantages_list_list_title","list_0_list_text":"Не имеет запаха и не пылит. Не содержит \\r\\nлетучих химикатов, не вызывает аллергии.","_list_0_list_text":"field_advantages_list_list_text","list_1_list_icon":95,"_list_1_list_icon":"field_advantages_list_list_icon","list_1_list_title":"Экологичность","_list_1_list_title":"field_advantages_list_list_title","list_1_list_text":"Производится из переработанной макулатуры \\r\\nи имеет невысокую стоимость.","_list_1_list_text":"field_advantages_list_list_text","list_2_list_icon":96,"_list_2_list_icon":"field_advantages_list_list_icon","list_2_list_title":"Капиллярная активность","_list_2_list_title":"field_advantages_list_list_title","list_2_list_text":"Принимает фиксированную форму. \\r\\nОбеспечивает приятный микроклимат, \\r\\nпропуская воздух и не накапливая пара и влаги.","_list_2_list_text":"field_advantages_list_list_text","list_3_list_icon":97,"_list_3_list_icon":"field_advantages_list_list_icon","list_3_list_title":"Теплоемкость","_list_3_list_title":"field_advantages_list_list_title","list_3_list_text":"Обладает теплопроводностью не выше 0,04 \\r\\nединиц. Защищена антисептиками от пожаров, \\r\\nплесени, грызунов и насекомых.","_list_3_list_text":"field_advantages_list_list_text","list":4,"_list":"field_advantages_list"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/certificates {"id":"block_62efee762b0c4","name":"acf/certificates","data":{"certificates_title":"Сертификаты качества","_certificates_title":"field_certificates_certificates_title","certificates_slider_0_certificates_image":101,"_certificates_slider_0_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_0_certificates_item_title":"Сертификат соответствия","_certificates_slider_0_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_0_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_0_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_1_certificates_image":102,"_certificates_slider_1_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_1_certificates_item_title":"Сертификат соответствия","_certificates_slider_1_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_1_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_1_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_2_certificates_image":103,"_certificates_slider_2_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_2_certificates_item_title":"Сертификат соответствия","_certificates_slider_2_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_2_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_2_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_3_certificates_image":104,"_certificates_slider_3_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_3_certificates_item_title":"Сертификат соответствия","_certificates_slider_3_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_3_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_3_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_4_certificates_image":105,"_certificates_slider_4_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_4_certificates_item_title":"Сертификат соответствия","_certificates_slider_4_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_4_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_4_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider_5_certificates_image":106,"_certificates_slider_5_certificates_image":"field_certificates_certificates_slider_certificates_image","certificates_slider_5_certificates_item_title":"Сертификат соответствия","_certificates_slider_5_certificates_item_title":"field_certificates_certificates_slider_certificates_item_title","certificates_slider_5_certificates_text":"№ РОСС RU.HB61.H00945","_certificates_slider_5_certificates_text":"field_certificates_certificates_slider_certificates_text","certificates_slider":6,"_certificates_slider":"field_certificates_certificates_slider"},"align":"","mode":"auto"} /-->\n\n<!-- wp:acf/learnmore {"id":"block_62f03bfe7c4bd","name":"acf/learnmore","data":{"learnmore_title":"Узнать больше об Эковате","_learnmore_title":"field_learnmore_learnmore_title","learnmore_text":"Заполните форму и получите на почту бесплатную презентацию \\r\\nо продукции «Ватэко». Из презентации вы узнаете о составе, \\r\\nсвойствах и способах нанесения эковаты.","_learnmore_text":"field_learnmore_learnmore_text","learnmore_shortcode":"","_learnmore_shortcode":"field_learnmore_learnmore_shortcode"},"align":"","mode":"auto"} /-->', 'Главная', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-08-08 01:27:10', '2022-08-07 22:27:10', '', 2, 'http://vateko.loc/?p=108', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(19, 2, 0),
(20, 2, 0),
(21, 2, 0),
(22, 2, 0),
(23, 2, 0),
(25, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 5),
(3, 3, 'wp_theme', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Главное меню', 'glavnoe-menyu', 0),
(3, 'vateko10', 'vateko10', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'vateko'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"49568179f950efae6cfd9f318944b99c1c3a9dd4f38de1e615950d1791c48e56";a:4:{s:10:"expiration";i:1659986004;s:2:"ip";s:10:"172.31.0.1";s:2:"ua";s:101:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36";s:5:"login";i:1659813204;}}'),
(17, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(18, 1, 'wp_user-settings-time', '1659878986'),
(19, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(20, 1, 'community-events-location', 'a:1:{s:2:"ip";s:10:"172.31.0.0";}'),
(21, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:21:"add-post-type-product";i:1;s:12:"add-post_tag";}'),
(23, 1, 'closedpostboxes_product', 'a:0:{}'),
(24, 1, 'metaboxhidden_product', 'a:0:{}'),
(25, 1, 'meta-box-order_product', 'a:4:{s:6:"normal";s:23:"acf-group_product_extra";s:8:"advanced";s:0:"";s:4:"side";s:0:"";s:15:"acf_after_title";s:0:"";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'vateko', '$P$BER7dme.UC2n82D0p7g8b6XHshH3Sg0', 'vateko', 'gorlov35@gmail.com', 'http://vateko.loc', '2022-08-06 19:12:38', '', 0, 'vateko') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

